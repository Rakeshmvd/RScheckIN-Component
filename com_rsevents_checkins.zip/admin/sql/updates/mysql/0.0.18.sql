ALTER TABLE `#__rseventscheckin` ADD `latitude` DECIMAL(9,7) NOT NULL DEFAULT 0.0;
ALTER TABLE `#__rseventscheckin` ADD `longitude` DECIMAL(10,7) NOT NULL DEFAULT 0.0;