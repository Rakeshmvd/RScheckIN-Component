<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * RseventsCheckinList Model
 *
 * @since  0.0.1
 */
class RseventsCheckinModelRseventsCheckins extends JModelList
{
	/* @var object item
	*/
   protected $item;
   public $_data = array();
   public $submission_ids = array();
   /**
	* Method to auto-populate the model state.
	*
	* This method should only be called once per instantiation and is designed
	* to be called on the first call to the getState() method unless the model
	* configuration flag to ignore the request is set.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @return	void
	* @since	2.5
	*/
   public function __construct($config = array())
   {
		
	   parent::__construct($config);
   }
   /**
	* Method to get a table object, load it if necessary.
	*
	* @param   string  $type    The table name. Optional.
	* @param   string  $prefix  The class prefix. Optional.
	* @param   array   $config  Configuration array for model. Optional.
	*
	* @return  JTable  A JTable object
	*
	* @since   1.6
	*/


	
   public function getEvents()
   {
	   $db		= JFactory::getDbo();
	   $query	= $db->getQuery(true);
	   $active	= rseventsproHelper::getConfig('active_events');
	   $tz		= JFactory::getConfig()->get('offset');
	   $filters=JFactory::getApplication()->input->get('filter');
	   
	   $state=isset($filters['state'])?$filters['state']:'';
	   
	   $query->clear()
		   ->select($db->qn('id', 'value'))
		   ->select($db->qn('name', 'text'))
		   ->select($db->qn('start'))
		   ->select($db->qn('form'))
		   ->from($db->qn('#__rseventspro_events'))
		   ->where($db->qn('registration') . ' = 1')
		   ->order($db->qn('start') . ' ASC');

	   $today = JFactory::getDate();
	   $today->setTime(0, 0, 0);
	   $today = $today->toSql();

	   $today = JFactory::getDate($today, $tz);
	   $today->setTimezone(new DateTimezone('UTC'));
	   $today = $today->toSql();
	   if($state==0){
		$query->where( $db->qn('completed') . ' = ' . $db->q("0")  );

	   }
	   if($state==1){
		$query->where( $db->qn('completed') . ' = ' . $db->q("1")  );

	   }
	   if($state==2){
		$query->where( $db->qn('archived') . ' = ' . $db->q("1")  );

	   }
	   if ($active) {
		 //  $query->where('((' . $db->qn('end') . ' >= ' . $db->q(JFactory::getDate()->toSql()) . ' AND ' . $db->qn('end') . ' != ' . $db->q($db->getNullDate()) . ') OR (' . $db->qn('end') . ' = ' . $db->q($db->getNullDate()) . ' AND ' . $db->qn('start') . ' >= ' . $db->q($today) . '))');
	   }

	   $db->setQuery($query);
	   if ($events = $db->loadObjectList()) {
		   foreach ($events as $i => $event) {
			   $events[$i]->text = $event->text . ' (' . rseventsproHelper::showdate($event->start) . ')';
		   }
	   }

	   return array_merge(
		   array(JHTML::_('select.option', 0, JText::_('COM_RSEVENTSPRO_SELECT_EVENT'))),
		   $events
	   );
   }

	

   
   public function checkFormColumns($formId,$fields_array)
   {
	  $db = JFactory::getDbo();
	  $results=[];
	  if(!empty($fields_array))
	  {
		  $fields_array_string=implode("','",$fields_array);
		  $fields_array_string="'$fields_array_string'";
		  $query = $db->getQuery(true)
			   ->select($db->qn('ColumnName'))
			   ->from($db->qn('#__rsform_submission_columns'))
			   ->where($db->qn('FormId') . ' = ' . $db->q($formId)  ) 
			   ->where($db->qn('ColumnName') . ' in (' . $fields_array_string .')' );
			   $db->setQuery($query);
			  $results = $db->loadObjectList();	 
	  }

	  return $results;
	   
   }
   
   public function isOrderingPossible($field)
   {
	   $db = $this->getDbo();

	   $query = $db->getQuery(true)
		   ->select($db->qn('SubmissionValueId'))
		   ->from($db->qn('#__rsform_submission_values'))
		   ->where($db->qn('FieldName') . ' = ' . $db->q($field))
		   ->where($db->qn('FormId') . ' = ' . $db->q($this->getFormId()));

	   $db->setQuery($query);
	   return $db->loadResult();
   }
   protected function getListQuery()
   {
	   $sortColumn 	= $this->getSortColumn();
	   $sortOrder 		= $this->getSortOrder();
	   $formId 		= $this->getFormId();
	   $filter 		= $this->getFilter();
	   
	   $languageFilter	= $this->getLang();
	   $isStaticHeader = in_array($sortColumn, array_keys($this->getStaticHeaders()));
	   $join			= false;
	   $db             = $this->getDbo();

	   $query = $db->getQuery(true)
		   ->select('s.*')
		   ->from($db->qn('#__rsform_submissions', 's'))
		   ->where($db->qn('s.FormId') . ' = ' . $db->q($formId));

	   // Only for export - export selected rows
	   if (!empty($this->submission_ids)) {
		   $query->where($db->qn('s.SubmissionId') . ' IN (' . implode(',', $db->q($this->submission_ids)) . ')');
	   }

	   // Check if there's a filter (search) set
	   /* if (!$this->export) {
		   if ($filter !== null && $filter !== '' && strlen($filter)) {
			   $or 			= array();
			   $join 			= true;
			   $escapedFilter  = $db->q('%' . $db->escape($filter) . '%', false);

			   if (!preg_match('#([^0-9\-: ])#', $filter)) {
				   $or[] = $db->qn('s.DateSubmitted') . ' LIKE ' . $escapedFilter;
			   }
			   $or[] = $db->qn('s.Username') . ' LIKE ' . $escapedFilter;
			   $or[] = $db->qn('s.UserIp') . ' LIKE ' . $escapedFilter;

			   if ($isStaticHeader) {
				   $or[] = $db->qn('sv.FieldValue') . ' LIKE ' . $escapedFilter;
			   } else {
				   $subquery = $db->getQuery(true)
					   ->select($db->qn('SubmissionId'))
					   ->from($db->qn('#__rsform_submission_values'))
					   ->where($db->qn('FormId') . ' = ' . $db->q($formId))
					   ->where($db->qn('FieldValue') . ' LIKE ' . $escapedFilter);

				   $or[] = $db->qn('s.SubmissionId') . ' IN (' . $subquery . ')';
			   }

			   $query->where('(' . implode(' OR ', $or) . ')');
		   }

		   if ($languageFilter) {
			   $query->where($db->qn('s.Lang') . ' = ' . $db->q($languageFilter));
		   }

		   if ($from = $this->getDateFrom()) {
			   $query->where($db->qn('s.DateSubmitted') . ' >= ' . $db->q(JFactory::getDate($from)->toSql()));
		   }

		   if ($to = $this->getDateTo()) {
			   $query->where($db->qn('s.DateSubmitted') . ' <= ' . $db->q(JFactory::getDate($to)->toSql()));
		   }
	   } */

	   // Order by static headers
	   if ($isStaticHeader) {
		   $query->order($db->qn('s.' . $sortColumn) . ' ' . $db->escape($sortOrder));
	   } else {
		   $join = true;

		   if ($this->isOrderingPossible($sortColumn)) {
			   $query->where($db->qn('sv.FieldName') . ' = ' . $db->q($sortColumn));
		   }

		   $query->order($db->qn('sv.FieldValue') . ' ' . $db->escape($sortOrder));
	   }

	   if ($join) {
		   $query->join('left', $db->qn('#__rsform_submission_values', 'sv') . ' ON (' . $db->qn('s.SubmissionId') . ' = ' . $db->qn('sv.SubmissionId') . ')')
			   ->group(array($db->qn('s.SubmissionId')));
	   }

	   return $query;
   }
   public function getSortColumn()
   {
	   return $this->getState('list.ordering', 'name');
   }

   public function getSortOrder()
   {
	   return $this->getState('list.direction', 'desc');
   }
   public function getHeaders($header_columns)
   {

	   $db     = JFactory::getDbo();
	   $formId = $this->getFormId();

	   $query = $db->getQuery(true)
		   ->select($db->qn('p.PropertyValue'))
		   ->from($db->qn('#__rsform_components', 'c'))
		   ->join('left', $db->qn('#__rsform_properties', 'p') . ' ON (' . $db->qn('c.ComponentId') . '=' . $db->qn('p.ComponentId') . ' AND ' . $db->qn('p.PropertyName') . ' = ' . $db->q('NAME') . ')')
		   ->join('left', $db->qn('#__rsform_component_types', 'ct') . ' ON (' . $db->qn('c.ComponentTypeId') . '=' . $db->qn('ct.ComponentTypeId') . ')')
		   ->where($db->qn('c.FormId') . ' = ' . $db->q($formId))
		   ->where($db->qn('c.Published') . ' = ' . $db->q(1));
	   if (!empty($header_columns)) {
		   $query->where($db->qn('p.PropertyValue') . '  IN (' . implode(',', $db->q($header_columns)) . ')');
	   }

	   $query->order($db->qn('c.Order'));

	   $headers = $db->setQuery($query)->loadColumn();

	   JFactory::getApplication()->triggerEvent('onRsformBackendGetSubmissionHeaders', array(&$headers, $formId));

	   // Get labels
	   $results = array();
	   if ($headers) {
		   foreach ($headers as $header) {
			   $value = $header;

			   $results[$value] = new RSFormProSubmissionHeader($value, $header, 0, $formId);
		   }
	   }

	   return $results;
   }
   public function updateSubmissionState($id, $state)
   {
	   $db = JFactory::getDbo();
	   $query = $db->getQuery(true);
	   $query->clear()
		   ->update($db->qn('#__rseventspro_users'))
		   ->set($db->qn('state') . ' = ' . (int) $state)
		   ->where($db->qn('id') . ' = ' . (int) $id);

	   $db->setQuery($query);
	   $db->execute();
   }
   public function addNote($form_id,$submissionid,$fieldname, $fieldvalue)
	{
		
		$db = JFactory::getDbo();
		$columns=['FormId','SubmissionId','FieldName','FieldValue'];
		$values = array($db->quote($form_id),$db->quote($submissionid),$db->quote($fieldname),$db->quote($fieldvalue)); 
		
		$query = $db->getQuery(true);
		$query->clear()
			->insert($db->quoteName('#__rsform_submission_values'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));
 
		$db->setQuery($query);
		$db->execute();
		return $new_row_id = $db->insertid();
	}

	public function updateNote($id, $value)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->clear()
			->update($db->qn('#__rsform_submission_values'))
			->set($db->qn('FieldValue') . ' = '  . $db->q($value))
			->where($db->qn('SubmissionValueId') . ' = ' . (int) $id);

		$db->setQuery($query);
		$db->execute();
	}

   public function getUnescapedFields()
   {
	   $db = JFactory::getDbo();
	   $query = $db->getQuery(true)
		   ->select($db->qn('p.PropertyValue'))
		   ->from($db->qn('#__rsform_components', 'c'))
		   ->join('left', $db->qn('#__rsform_properties', 'p') . ' ON (' . $db->qn('c.ComponentId') . '=' . $db->qn('p.ComponentId') . ')')
		   ->where($db->qn('c.FormId') . ' = ' . $db->q($this->getFormId()))
		   ->where($db->qn('c.ComponentTypeId') . ' = ' . $db->q(RSFORM_FIELD_FILEUPLOAD))
		   ->where($db->qn('p.PropertyName') . ' = ' . $db->q('NAME'));
	   $fields = $db->setQuery($query)->loadColumn();


	   return $fields;
   }
   public function getPermission()
   {
	   $user = JFactory::getUser();
	   $groups = $user->get('groups');
	   $gp = [];
	   foreach ($groups as $group) {
		   $gp[] = '%"' . $group . '"%';
	   }

	   $db = JFactory::getDbo();
	   $query = $db->getQuery(true)
		   ->select('*')
		   ->from($db->qn('#__rseventspro_groups', 'g'));
	   $query->where('1  =  1');
	   $group_wheres = [];
	   foreach ($groups as $group) {
		   $group_wheres[] = $db->qn('g.jgroups') . '  LIKE  ' .  $db->quote('%"' . $group . '"%');
	   }
	   $query->extendWhere('AND', $group_wheres, 'OR');
	   $query->extendWhere('OR', [$db->qn('g.jusers') . '  LIKE  ' .  $db->quote('%"' . $user->id . '"%')], '');

	   $db->setQuery($query);
	   //echo $query;
	   return $data = $db->loadObjectList();
   }
   public function getSubmissions($formId)
   {

	   $this->setFormId($formId);
	   if (empty($this->_data)) {

		   $app	= JFactory::getApplication();
		   $db     = $this->getDbo();
		   $form   = $this->getFormProperties();

		   $multipleSeparator = $form->MultipleSeparator;
		   if ($this->multipleSeparator !== null) {
			   $multipleSeparator = $this->multipleSeparator;
		   }
		   $multipleSeparator = str_replace(array('\n', '\r', '\t'), array("\n", "\r", "\t"), $multipleSeparator);

		   if (empty($form)) {
			   return $this->_data;
		   }

		   $uploadFields 	= array();
		   $multipleFields = array();
		   $textareaFields = array();
		   $fieldTypes = $this->getSpecialFields();
		   if (isset($fieldTypes['uploadFields'])) {
			   $uploadFields = $fieldTypes['uploadFields'];
		   }
		   if (isset($fieldTypes['multipleFields'])) {
			   $multipleFields = $fieldTypes['multipleFields'];
		   }
		   if (isset($fieldTypes['textareaFields'])) {
			   $textareaFields = $fieldTypes['textareaFields'];
		   }

		   $db->setQuery("SET SQL_BIG_SELECTS=1")->execute();

		   $results = $this->_getList($this->getListQuery());

		   foreach ($results as $result) {
			   $this->_data[$result->SubmissionId] = array(
				   'SubmissionId'     => $result->SubmissionId,
				   'FormId'           => $result->FormId,
				   'DateSubmitted'    => RSFormProHelper::getDate($result->DateSubmitted),
				   'UserIp'           => $result->UserIp,
				   'Username'         => $result->Username,
				   'UserId'           => $result->UserId,
				   'Lang'             => $result->Lang,
				   'confirmed'        => $result->confirmed ? JText::_('RSFP_YES') : JText::_('RSFP_NO'),
				   'SubmissionValues' => array(),
			   );
		   }

		   $submissionIds = array_keys($this->_data);

		   if (!empty($submissionIds)) {
			   $must_escape = $app->input->get('view') == 'submissions' && $app->input->get('layout') == 'default';

			   $query = $db->getQuery(true)
				   ->select('*')
				   ->from($db->qn('#__rsform_submission_values'))
				   ->where($db->qn('SubmissionId') . ' IN (' . implode(',', $db->q($submissionIds)) . ')');

			   $results = $db->setQuery($query)->loadObjectList();
			   foreach ($results as $result) {
				   // Check if this is an upload field
				   if (in_array($result->FieldName, $uploadFields) && !empty($result->FieldValue) && !$this->export) {
					   $files = RSFormProHelper::explode($result->FieldValue);

					   $values = array();
					   foreach ($files as $file) {
						   $values[] = '<a href="index.php?option=com_rsform&amp;task=submissions.viewfile&amp;id=' . $result->SubmissionValueId . '&amp;file=' . md5($file) . '">' . RSFormProHelper::htmlEscape(basename($file)) . '</a>';
					   }

					   $result->FieldValue = implode('<br />', $values);
				   } else {
					   // Check if this is a multiple field
					   if (in_array($result->FieldName, $multipleFields)) {
						   $result->FieldValue = str_replace("\n", $multipleSeparator, $result->FieldValue);
					   }
					   // Transform new lines
					   elseif ($form->TextareaNewLines && in_array($result->FieldName, $textareaFields)) {
						   if ($must_escape) {
							   $result->FieldValue = RSFormProHelper::htmlEscape($result->FieldValue);
						   } elseif ($this->exportType === 'csv' && !$this->stripLines) {
							   $result->FieldValue = nl2br($result->FieldValue);
						   }
					   } elseif ($must_escape) {
						   $result->FieldValue = RSFormProHelper::htmlEscape($result->FieldValue);
					   }
				   }

				   $this->_data[$result->SubmissionId]['SubmissionValues'][$result->FieldName] = array(
					   'Value' => $result->FieldValue,
					   'Id'    => $result->SubmissionValueId
				   );
			   }
		   }
		   unset($results);
	   }

	   return $this->_data;
   }
   public function getFormProperties()
   {
	   return RSFormProHelper::getForm($this->getFormId());
   }

   public function getFormId()
   {

	   $formId = $this->firstFormId;



	   return $formId;
   }
   public function setFormId($formId)
   {

	   $this->firstFormId = $formId;
   }
   public function getFilterState()
   {
	   return $this->getState('filter.state');
   }

   public function getDateFrom()
   {
	   return $this->getState('filter.dateFrom');
   }

   public function getDateTo()
   {
	   return $this->getState('filter.dateTo');
   }

   public function getLang()
   {
	   return $this->getState('filter.language');
   }

   public function getFilter()
   {
	   return $this->getState('filter.search');
   }

   public function getSpecialFields()
   {
	   return RSFormProHelper::getDirectoryFormProperties($this->getFormId(), true);
   }

   public function getStaticHeaders()
   {
	   $headers = array('SubmissionId', 'DateSubmitted', 'UserIp', 'Username', 'UserId', 'Lang');

	   if ($this->addConfirmedHeader()) {
		   $headers[] = 'confirmed';
	   }

	   $results = array();

	   foreach ($headers as $header) {
		   $results[$header] = new RSFormProSubmissionHeader($header, JText::_('RSFP_' . $header), 1, $this->getFormId());
	   }

	   return $results;
   }

   public function addConfirmedHeader()
   {
	   if ($form = $this->getFormProperties()) {
		   return (bool) $form->ConfirmSubmission;
	   }

	   return false;
   }

   public function confirm($id, $code,$confirm) {
	$db		= JFactory::getDbo();
	$query	= $db->getQuery(true);
	
	$query->select($db->qn('id'))
		->from('#__rseventspro_confirmed')
		->where($db->qn('ids').' = '.$db->q($id))
		->where($db->qn('code').' = '.$db->q($code));
	$db->setQuery($query);
	if (!$db->loadResult() && $confirm ) {
		$query->clear()
			->insert('#__rseventspro_confirmed')
			->set($db->qn('ids').' = '.$db->q($id))
			->set($db->qn('code').' = '.$db->q($code));
		$db->setQuery($query);
		if ($db->execute()) {
			return json_encode(array('status' => true, 'message' => JText::_('JYES')));
		}
	}

	if ($db->loadResult() && !$confirm ) {
		$conditions = array(
			$db->qn('ids') .  ' = '.$db->q($id) ,
			$db->qn('code') .  ' = '.$db->q($code) ,
		);
		$query->clear()
			->delete('#__rseventspro_confirmed');
			$query->where($conditions);
		$db->setQuery($query);
		if ($db->execute()) {
			return json_encode(array('status' => true, 'message' => JText::_('JYES')));
		}
	}
	return json_encode(array('status' => false));
} 
}

class RSFormProSubmissionHeader
{
   /* @var string Holds the actual value of the header */
   public $value;

   /* @var string Holds the label (displayed) value of the header */
   public $label;

   /* @var int 0 - form field, 1 - static submission header */
   public $static;

   /* @var int Checks if this header is shown in the submissions list */
   public $enabled;

   public function __construct($value, $label, $static = 0, $formId = 0)
   {
	   $this->value = $value;
	   $this->label = $label;
	   $this->static = $static;

	   if ($formId) {
		   $this->enabled = $this->isHeaderEnabled($formId);
	   }
   }

   public function __toString()
   {
	   return $this->value;
   }

   protected function isHeaderEnabled($formId)
   {
	   static $cache = array();

	   if (!isset($cache[$formId])) {
		   $cache[$formId] = (object) array(
			   'staticHeaders' => array(),
			   'headers'       => array()
		   );

		   $db = JFactory::getDbo();

		   $query = $db->getQuery(true)
			   ->select($db->qn('ColumnName'))
			   ->select($db->qn('ColumnStatic'))
			   ->from($db->qn('#__rsform_submission_columns'))
			   ->where($db->qn('FormId') . ' = ' . $db->q($formId));

		   if ($results = $db->setQuery($query)->loadObjectList()) {
			   foreach ($results as $result) {
				   if ($result->ColumnStatic) {
					   $cache[$formId]->staticHeaders[] = $result->ColumnName;
				   } else {
					   $cache[$formId]->headers[] = $result->ColumnName;
				   }
			   }
		   }
	   }

	   $array = $this->static ? 'staticHeaders' : 'headers';

	   if (empty($cache[$formId]->headers) && empty($cache[$formId]->staticHeaders)) {
		   return true;
	   }

	   return in_array($this->value, $cache[$formId]->{$array});
   }
   
}
 