DROP TABLE IF EXISTS `#__rseventscheckin`;

CREATE TABLE `#__rseventscheckin` (
	`id`       INT(11)     NOT NULL AUTO_INCREMENT,
	`greeting` VARCHAR(25) NOT NULL,
	`published` tinyint(4) NOT NULL DEFAULT '1',
	PRIMARY KEY (`id`)
)
	ENGINE=InnoDB 
	AUTO_INCREMENT =0
	DEFAULT CHARSET=utf8mb4 
	DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT INTO `#__rseventscheckin` (`greeting`) VALUES
('Hello World!'),
('Good Bye World!');