<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * General Controller of RseventsCheckin component
 *
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 * @since       0.0.7
 */
class RseventsCheckinController extends JControllerLegacy
{
	/**
	 * The default view for the display method.
	 *
	 * @var string
	 * @since 12.2
	 */
	protected $default_view = 'rseventscheckins';
}
