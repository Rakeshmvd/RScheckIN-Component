<table class="table table-striped table-bordered mt-5">

    <thead>
        <th><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_UNCONFIRM_LABEL'); ?></th>
        <th><?php echo JHtml::_('searchtools.sort', 'COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_NAME', 'u.name', $listDirn, $listOrder); ?></th>
        <?php if (empty($this->event_id)) {  ?>
            <th class="d-none d-sm-table-cell nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?>"><?php echo JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_EVENT'); ?></th>
        <?php   } ?>
        <th   class="nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">
            <?php echo JHtml::_('searchtools.sort', 'COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TICKETS', 'ticket', $listDirn, $listOrder); ?>

        </th>
        <th width="15%" class="nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone"><?php echo JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TOTAL'); ?></th>
        <?php 
        $HAS_NOTE_COLUMN=false;
        foreach ($this->headers as $header) {
            if(!in_array($header->value,$this->header_columns)){
                continue;
             }	
        ?>
            <th <?php if (!$header->enabled) { ?>style="display: none" <?php } ?> class="title d-none d-sm-table-cell ">
                <?php
                if ($header->label == 'Subscription_Note') {
                    $HAS_NOTE_COLUMN=true;
                    echo JHtml::_('searchtools.sort', 'COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_LABEL', 'Subscription_Note', $listDirn, $listOrder);
                } else {
                    echo   $header->label;
                }
                ?>
            </th>
        <?php
        }
        
         if($HAS_NOTE_COLUMN){  
            ?>
        <th></th> <?php
        } ?>
        <th class="nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">

            <?php echo JHtml::_('searchtools.sort', 'JGRID_HEADING_ID', 'u.id', $listDirn, $listOrder); ?>
        </th>
    </thead>
    <tbody id="rseprocontainer">
        <?php foreach ($this->subscriptions as $i => $item) {
            $submission = [];
            $rsform_submissionId = $item->SubmissionId;
            if (isset($this->submissions[$rsform_submissionId])) {
                $submission = $this->submissions[$rsform_submissionId];
            }
            $discount =  '';
            if ($item->discount > 0) {

                $discount = " <span class='ribbon'> - " . rseventsproHelper::currency($item->discount) . "</span>";
            }

            $ticket_column = $this->rs_submission_field_ticket;
            //$tickets = $submission['SubmissionValues'][$ticket_column]['Value'];
            $note_column = $this->rs_submission_field_note;
            $note = '';
            $note_field_id = 0;
            if (!empty($submission)) {
                if (isset($submission['SubmissionValues'][$note_column]['Value']))
                    $note = $submission['SubmissionValues'][$note_column]['Value'];
                if (isset($submission['SubmissionValues'][$note_column]['Id']))
                    $note_field_id = $submission['SubmissionValues'][$note_column]['Id'];
            }



            $tickets = rseventsproHelper::getUserTickets($item->id);

            $has_unconfirmed_tickets = false;

            $purchasedtickets = '';
            $purchasedtickets = '';
            if ($tickets) {

                foreach ($tickets as $ticket) {
                    $purchasedtickets_rows = '';
                    for ($j = 1; $j <= $ticket->quantity; $j++) {

                        $code    = md5($item->id . $ticket->id . $j);
                        $code    = substr($code, 0, 4) . substr($code, -4);
                        $code    = rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-') . $item->id . '-' . $code;
                        $code   = in_array(rseventsproHelper::getBarcodeOptions('barcode', 'C39'), array('C39', 'C93')) ? strtoupper($code) : $code;
                        $confirmed = rseventsproHelper::confirmed($item->id, $code);

                        $hasLayout = rseventsproHelper::hasPDFLayout($ticket->layout, $item->SubmissionId);
                        //$purchasedtickets_rows .= '<td class="'.RSEventsproAdapterGrid::styles(array('center')).'">'.($ticket->id ? $code : '-').'</td>';



                        if (!$confirmed) {
                            $purchasedtickets_rows .= '<tr>';
                            $purchasedtickets_rows .= '<td>' . $ticket->name . ' (' . ($ticket->price > 0 ? rseventsproHelper::currency($ticket->price) : JText::_('COM_RSEVENTSPRO_GLOBAL_FREE')) . ')' . '</td>';
                            $purchasedtickets_rows .= '</tr>';
                            //$purchasedtickets .=$purchasedtickets_rows;
                        }
                    }
                    if (!empty($purchasedtickets_rows))
                        $purchasedtickets .= '<table   ">' . $purchasedtickets_rows . '</table>';
                }
            }
            if (!empty($purchasedtickets)) {
        ?>
                <tr class="row<?php echo $i % 2; ?>">
                    <td class="nowrap has-context">

                        <?php echo rseventsproHelper::showdate($item->date, null, true); ?>
                    </td>
                    <td class="nowrap has-context">
                        <?php echo $item->name; ?><br />

                    </td>
                    <?php if (empty($this->event_id)) {  ?>
                        <td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> nowrap has-context d-none d-sm-table-cell">
                            <a href="<?php echo JRoute::_('index.php?option=com_rseventspro&task=event.edit&id=' . $item->ide); ?>"><?php echo $item->event; ?></a> <br />
                            <?php if ($item->allday) { ?>
                                <?php echo rseventsproHelper::showdate($item->start, rseventsproHelper::getConfig('global_date')); ?>
                            <?php } else { ?>
                                (<?php echo rseventsproHelper::showdate($item->start); ?> - <?php echo rseventsproHelper::showdate($item->end); ?>)
                            <?php } ?>
                        </td>
                    <?php } ?>
                    <td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?>hidden-phone">
                        <?php echo $purchasedtickets;       ?>
                    </td>
                    <td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> box  hidden-phone">

                        <?php $total = rseventsproHelper::total($item->id); ?>
                        <?php $total = $total > 0 ? $total : 0; ?>
                        <?php echo rseventsproHelper::currency($total); ?><?php echo $discount; ?>
                    </td>

                    <?php
                    foreach ($this->headers as $header) {
                        if(!in_array($header->value,$this->header_columns)){
                            continue;
                         }	
                    ?>
                        <td class="d-none d-sm-table-cell <?php if ($header->label == 'Subscription_Note') { echo "note_{$item->SubmissionId}"; } ?>" <?php if (!$header->enabled) { ?>style="display: none" <?php } ?>>
                            <?php
                            if (isset($submission['SubmissionValues'][$header->value]['Value'])) {
                                if (in_array($header->value, $this->unescapedFields)) {
                                    echo $submission['SubmissionValues'][$header->value]['Value'];
                                } else {
                                    $escapedValue = $this->escape($submission['SubmissionValues'][$header->value]['Value']);

                                    if (isset($this->form->TextareaNewLines) && !empty($this->specialFields['textareaFields']) && in_array($header->value, $this->specialFields['textareaFields'])) {
                                        $escapedValue = nl2br($escapedValue);
                                    }

                                    echo $escapedValue;
                                }
                            }
                            ?>
                        </td>
                    <?php
                    }
                    if($HAS_NOTE_COLUMN){  
                        ?>

                    <td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">
                        <?php if (!empty($item->SubmissionId)) {  ?>
                            <i data-bs-toggle="modal" data-formid="<?php echo $this->form_id; ?>" data-submissionid="<?php echo $rsform_submissionId; ?>" data-noteid="<?php echo $note_field_id; ?>" data-note="<?php if (!empty($note)) { ?>1<?php } ?>" data-bs-target="#NoteModal" class=" note-opener note-opener-<?php echo $note_field_id;  ?> fa fa-file 
						<?php if (!empty($note)) { ?> has-note text-success <?php } ?>"></i>
                            
                        <?php } else { ?>

                            <i class="<?php echo $btn_text_color = ' text-danger ';  ?> fa fa-file "></i> <?php
                        } ?>
                        <div class="d-none note-container note-container-<?php echo $item->SubmissionId; ?>"><?php echo $note; ?></div>
                    </td><?php
                    }
                    ?>
                    <td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">
                        <?php echo (int) $item->id; ?>
                    </td>
                </tr>
        <?php }
        } ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="10" style="text-align: center;">
                <?php echo $this->pagination->getListFooter(); ?>
            </td>
        </tr>
    </tfoot>
</table>