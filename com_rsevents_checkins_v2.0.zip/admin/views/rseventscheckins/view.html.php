<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * RseventsCheckins View
 *
 * @since  0.0.1
 */
use Joomla\CMS\Factory;
require_once JPATH_SITE. '/components/com_rseventspro/helpers/adapter/adapter.php';
require_once JPATH_SITE. '/components/com_rseventspro/helpers/rseventspro.php';
require_once JPATH_ADMINISTRATOR . '/components/com_rsform/helpers/rsform.php'; 
class RseventsCheckinViewRseventsCheckins extends JViewLegacy
{
	/**
	 * Display the Hello World view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	function display($tpl = null)
	{
		
		$app   = Factory::getApplication();
		$config =  JComponentHelper::getParams('com_rseventscheckin');
		$this->rs_submission_field_ticket = $config->get('rs_submission_field_ticket');
		$model=$this->getModel();
		$filter_state=$app->input->get('filter_state');
		if(!$filter_state){
			$model->setState('filter.state', "");	
		}
		$note_column='Subscription_Note' ;
		$permissions=$model->getPermission();
		//var_dump($permissions);
		$this->can_view_subscriptions=0;
		$this->can_edit_subscriptions=0;
		$this->can_change_subscriptions=0;
		$this->can_delete_subscriptions=0;
		foreach($permissions as $permission){
			if($permission->can_view_subscriptions==1){
				$can_view_subscriptions=$permission->can_view_subscriptions;
				$this->can_view_subscriptions=$can_view_subscriptions;
			}
			if($permission->can_edit_subscriptions==1){
				$can_edit_subscriptions=$permission->can_edit_subscriptions;
				$this->can_edit_subscriptions=$can_edit_subscriptions;
			}
			if($permission->can_change_subscriptions==1){
				$can_change_subscriptions=$permission->can_change_subscriptions;
				$this->can_change_subscriptions=$can_change_subscriptions;
			}
			if($permission->can_delete_subscriptions==1){
				$can_delete_subscriptions=$permission->can_delete_subscriptions;
				$this->can_delete_subscriptions=$can_delete_subscriptions;
			}
		}
		 
		
		$language = JFactory::getLanguage();
	    $language->load('com_rseventspro', JPATH_ADMINISTRATOR);
		$_prefix = 'RseventsproModel';
		JModelLegacy::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_rseventspro/models', $_prefix);

		$subscription_model = JModelLegacy::getInstance('Subscription', $_prefix);
		$this->events =	$subscription_model ->getEvents();
		 
		$event_lists=	$model->getEvents();
	    $events=$event_lists;
		$this->event_id=JFactory::getApplication()->input->get('filter_event'); 
		$this->form_id=0; 
		
		foreach ($events as $i => $event) 
		{
			$event_text=isset($event->start)? ' (' . rseventsproHelper::showdate($event->start) . ')':'';
			$events[$i]->text = $event->text . $event_text  ;
			if(!empty($this->event_id) && ($event->value==$this->event_id))
			{
					$this->form_id=$event->form;
			}
		}
		$this->events =$events;
		$submission_fields_array=[];
	
		if($this->form_id>0){
			/* $submission_fields=$config->get('rs_submission_fields');
			$submission_fields_array=explode(',',$submission_fields); */
			$submission_fields_array[]=$note_column;
			$submission_fields=$model->checkFormColumns($this->form_id,$submission_fields_array);
			foreach($submission_fields as $submission_field){
				$submission_fields_array[]=$submission_field->ColumnName;
			}
		}
		
		
		//$this->set('list.ordering', 'u.name'); 
		
		 
	//	$event_id=$app->input->get('filter_event');
	$_prefix = 'RseventsCheckInModel';
	JModelLegacy::addIncludePath(JPATH_SITE . '/components/com_rseventscheckin/models', $_prefix);
	$subscriptions_model = JModelLegacy::getInstance('Subscriptions', $_prefix);
			 
			
			$this->event_state=$app->input->get('filter_state',1);
			 
			$ajax_action=JFactory::getApplication()->input->get('action','','string');
			if($ajax_action=='ajax_confirm')
			{
				$confirm_state=$app->input->get('confirm');
				$confirm_id=$app->input->get('confirm_id');
				$code=$app->input->get('code');
				if($confirm_state=='true'){
					$confirm=true;
				}else{
					$confirm=false;
				}
				 
				$model->confirm($confirm_id, $code,$confirm) ;
				echo "Confirmation State changed";
				die;
			}

			if($ajax_action=='ajax_save_note')
			{
				$message = $app->input->get('message', '', 'string');
				$field_id = $app->input->get('field_id');
				$form_id = $app->input->get('form_id');
				$submission_id = $app->input->get('submission_id');
				if($field_id==0){
					$model->addNote($form_id,$submission_id,$note_column, $message);	
				}else{
					$model->updateNote($field_id, $message);
				}
				
				echo "Note Updated ";
				die;
			}

			
			if($this->event_state>0){
				$subscriptions_model->setState('filter.state', $this->event_state);
			}
			
			 $subscriptions_model->setState('list.direction', 'asc');  
			 $subscriptions_model->setState('filter.order', 'u.name');
			 //$subscriptions_model->setState('list.direction', 'asc');
		 
			 
			// $subscriptions_model->setState('list.direction', 'asc');
			//var_dump($subscriptions_model);
			 
			if(!empty($this->event_id)){
				$app->input->set('filter_event', $this->event_id); 
				$subscriptions_model->setState('filter.event', $this->event_id);
			}
			 
			if($app->input->get('export')==1){
				$subscriptions_model->setState('list.limit',0);
			}
			$subscriptions=[];
			if(!empty($this->event_id)){
				$subscriptions=$subscriptions_model->getItems() ;
				
			}
			
			$this->subscriptions=$subscriptions;
			 
			$submission_ids=[];
			foreach ($this->subscriptions as $i => $item) {
				$submission_ids[]=$item->SubmissionId;
			}
			
			

			$rs_submission_form_id = $config->get('rs_submission_form');
		$this->submission_form_id = $rs_submission_form_id;
		if(!empty($this->form_id)){
			$this->submission_form_id = $this->form_id;
		}
		 
		$this->rs_submission_field_note ="";
		 
		 if(in_array($note_column,$submission_fields_array)){
			$this->rs_submission_field_note = $note_column;	
		 }
			$this->rs_submission_fields = ''; 
			$this->state 		 = $subscriptions_model->getState();
			$this->pagination=    $subscriptions_model->getPagination() ;
 		
			
			$model->submission_ids=$submission_ids;
			$submissions=$model->getSubmissions($rs_submission_form_id);
			$header_columns=$submission_fields_array; 
			$this->header_columns=$header_columns;
			$this->headers 		 =[];
			if(!empty($header_columns)){
				$this->headers 		 =$model->getHeaders($header_columns);
			}
			
			
			$this->unescapedFields 		 =$model->getUnescapedFields();
		 	$this->submissions=$submissions;

			
		 //$this->pagination=$submission_model->getPagination() ;
		
		// Get the form to display
		 
		// Get the javascript script file for client-side validation
		 

		// Propose current language as default
		if (JLanguageMultilang::isEnabled())
		{
			$lang = JFactory::getLanguage()->getTag();
			//$this->form->setFieldAttribute('language', 'default', $lang);
		}

		//$this->filterForm = $app->input->get('FilterForm', 'rseventscheckin', 'filter');
	 	$this->filterForm    	= $this->get('FilterForm' );
	 
		$this->activeFilters 	= $this->get('ActiveFilters' );
		if (!empty($this->event_id)) {
			$ticketXml = new SimpleXMLElement('<field name="ticket" type="hidden" default="" />');
			$this->filterForm->setField($ticketXml, 'filter', true);
		}
		// Check that the user has permissions to create a new rseventscheckin record
		$this->canDo = JHelperContent::getActions('com_rseventscheckin');
		if($this->canDo->get('core.create')){
			$this->can_view_subscriptions=1;
			$this->can_edit_subscriptions=1;
			$this->can_change_subscriptions=1;
			$this->can_delete_subscriptions=1;	
		} 
		if ($this->can_view_subscriptions == 0) 
		{
			$app = JFactory::getApplication(); 
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->setHeader('status', 403, true);
			return;
		}
       
		if($app->input->get('export')==1){
			$status=$app->input->get('status',1);
			$this->downloadCSV($status);
			exit;
		}

		 
		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors), 500);
		}
		 
		$this->setJDocument();	
		$this->addToolBar();	
		// Display the template
		parent::display($tpl);

		// Set the document
		
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function addToolBar()
	{
		$title = JText::_('COM_RSEVENTSCHECKIN_MANAGER_RSEVENTSCHECKINS');

		if ($this->pagination->total)
		{
			$title .= "<span style='font-size: 0.5em; vertical-align: middle;'>(" . $this->pagination->total . ")</span>";
		}

		JToolBarHelper::title($title, 'rseventscheckin');

		if ($this->canDo->get('core.create')) 
		{
			//JToolBarHelper::addNew('rseventscheckin.add', 'JTOOLBAR_NEW');
		}
		if ($this->canDo->get('core.edit')) 
		{
			//JToolBarHelper::editList('rseventscheckin.edit', 'JTOOLBAR_EDIT');
		}
		if ($this->canDo->get('core.delete')) 
		{
			//JToolBarHelper::deleteList('', 'rseventscheckins.delete', 'JTOOLBAR_DELETE');
		}
		if ($this->canDo->get('core.edit') || JFactory::getUser()->authorise('core.manage', 'com_checkin'))
		{
			//JToolBarHelper::checkin('rseventscheckins.checkin');
		}

		if(!empty($this->event_id)){
			$bar =  JToolBar::getInstance('toolbar');
			$bar->appendButton( 'LINK', 'icon-download', 'COM_RSEVENTSCHECKIN_EXPORT_UNCONFIRMED_CSV', 'index.php?option=com_rseventscheckin&export=1&status=0&filter_event='.$this->event_id );
			$bar->appendButton( 'LINK', 'icon-download', 'COM_RSEVENTSCHECKIN_EXPORT_CONFIRMED_CSV', 'index.php?option=com_rseventscheckin&export=1&status=1&filter_event='.$this->event_id );
		
		}
			 
		 
		if ($this->canDo->get('core.admin')) 
		{
			JToolBarHelper::divider();
			JToolBarHelper::preferences('com_rseventscheckin');
		}
		 
	}
	/**
	 * Method to set up the document properties
	 *
	 * @return void
	 */
	protected function setJDocument() 
	{
		$document = JFactory::getDocument();
		$document->addStyleSheet(JURI::root() . "/components/com_rseventscheckin"
		. "/views/rseventscheckin/w3.css");
		$document->setTitle(JText::_('COM_RSEVENTSCHECKIN_ADMINISTRATION'));
	}
	protected function getUser($id) {
		if ($id > 0)
			return JFactory::getUser($id)->get('username');
		
		return JText::_('COM_RSEVENTSPRO_GLOBAL_GUEST');
	}
	
	protected function getStatus($state) {
		if ($state == 0) {
			return '<font color="blue">'.JText::_('COM_RSEVENTSPRO_RULE_STATUS_INCOMPLETE').'</font>';
		} else if ($state == 1) {
			return '<font color="green">'.JText::_('COM_RSEVENTSPRO_RULE_STATUS_COMPLETE').'</font>';
		} else if ($state == 2) {
			return '<font color="red">'.JText::_('COM_RSEVENTSPRO_RULE_STATUS_DENIED').'</font>';
		} else if ($state == 3) {
			return '<font color="orange">'.JText::_('COM_RSEVENTSPRO_RULE_STATUS_REFUNDED').'</font>';
		}
	}

	protected function downloadCSV($status)
	{
		$file_name= ($status==1)?JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CONFIRM_LABEL'):JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_UNCONFIRM_LABEL');
		 
		foreach ($this->subscriptions as $i => $item) 
		{
			$file_name.=" - " .$item->event." - ";;  
			if ($item->allday){  
				$file_name.= rseventsproHelper::showdate($item->start, rseventsproHelper::getConfig('global_date'));  
			  } else  {
				$file_name.=" (". rseventsproHelper::showdate($item->start) ." - ". rseventsproHelper::showdate($item->end) .")";
			  } 
			break; 
		} 
		 
		//ob_clean();
		header('Content-Type: text/csv; charset=utf-8');
		 
		header("Content-Disposition: attachment; filename={$file_name}.csv");
		 
		$output = fopen('php://output', 'w');
		$coloums= [
			'#',
			JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_NAME'),
			JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TICKETS')  ,
			JText::_('COM_RSEVENTSCHECKIN_SUBSCSRIPTION_STATUS'),
			JText::_('COM_RSEVENTSPRO_EVENT_TICKET_PRICE'),
			JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TOTAL') ,
			JText::_('COM_RSEVENTSPRO_SUBSCRIBER_DISCOUNT'),
			JText::_('COM_RSEVENTSPRO_SUBSCRIBER_DISCOUNT_CODE'),
			JText::_('COM_RSEVENTSPRO_SUBSCRIBER_DATE'),
			
		];
		
		
	   foreach ($this->headers as $header) {
				$coloums[]=$header->label;
		}
		//$coloums[]=JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_LABEL');
		$coloums[]=JText::_('JGRID_HEADING_ID');
		 
		 fputcsv($output,$coloums);
		$index=0;
		
		$loop=-1;
	 
		foreach ($this->subscriptions as   $k=>$subscription) 
		{
			$loop++;
			 $submission=[];
			 
		   //if(isset($this->subscriptions[$loop])){

			   
			$item=$subscription;
			$coupon=$item->coupon;	
			$rsform_submissionId = $item->SubmissionId;
			
			 
			if(!empty($item->SubmissionId)){
				if(isset($this->submissions[$rsform_submissionId])){
					$submission = $this->submissions[$rsform_submissionId];	
				}
			
			} 
			
			$ticket_column = $this->rs_submission_field_ticket;
			//$tickets = $submission['SubmissionValues'][$ticket_column]['Value'];
			$note_column = $this->rs_submission_field_note;
			$note = '';
			$coupon = '';
			$discount = '';
			$tickets = rseventsproHelper::getUserTickets($item->id);
			 
			
				//if($item->state==0 && $status==1){ continue;} 
				$total = rseventsproHelper::total($item->id); 
				$total = $total > 0 ? $total : 0; 
				 $ticket_total=rseventsproHelper::currency($total); 
				 $confirm_status= strip_tags($this->getStatus($item->state));
				if ($tickets) {
					
					foreach ($tickets as $ticket) 
					{
						$coupon =$item->coupon;
						if(!empty($item->discount)){
							$discount =rseventsproHelper::currency($item->discount);
						}
						$index_changed=false; 
						for ($j = 1; $j <= $ticket->quantity; $j++) 
						{
							$confirmed =false;
							
							$ticket_details=  $ticket->name  ;
							$ticket_price=($ticket->price > 0 ? rseventsproHelper::currency($ticket->price) : JText::_('COM_RSEVENTSPRO_GLOBAL_FREE'));
							 
								$code	= md5($item->id.$ticket->id.$j);
								$code	= substr($code,0,4).substr($code,-4);
								$code	= rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-').$item->id.'-'.$code;
								$code   = in_array(rseventsproHelper::getBarcodeOptions('barcode', 'C39'), array('C39', 'C93')) ? strtoupper($code) : $code;
								$confirmed = rseventsproHelper::confirmed($item->id, $code);
								$hasLayout = rseventsproHelper::hasPDFLayout($ticket->layout,$item->SubmissionId);
								
							if(($confirmed && $status==1) || (!$confirmed && $status==0) )
							{
								 
								$date=rseventsproHelper::showdate($item->date, null, true);
								$state=($status==1)?JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CONFIRM_LABEL'):JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_UNCONFIRM_LABEL');
								$subscriber_name= $item->name;
								$event_details=$item->event;
								$itemid= $item->id;
								 
								  if ($item->allday) { 
									$event_details.= rseventsproHelper::showdate($item->start, rseventsproHelper::getConfig('global_date'));
								  }
								  else {
									$event_details.=" ("  .  rseventsproHelper::showdate($item->start)." - ". rseventsproHelper::showdate($item->end) .")";
								 }  
								 $name=$item->name;
								 if(!isset($subs_array[$itemid])){
									$index++;
									$subs_array[$itemid]=$index; 
								 } 
								 $subindex=$subs_array[$itemid];
									 
								 $data_coloums=[
									$index,										
									$subscriber_name,
									$ticket_details  ,
									$confirm_status, 
									$ticket_price,
									$ticket_total,
									$discount,
									$coupon,
									 $date
									   
								 ];
								 foreach ($this->headers as $header) {
									  //if ($header->enabled) { 
										 
											if (isset($submission['SubmissionValues'][$header->value]['Value'])) {
												if (in_array($header->value, $this->unescapedFields)) {
													$data_coloums[]= $submission['SubmissionValues'][$header->value]['Value'];
												} else {
													$escapedValue = $this->escape($submission['SubmissionValues'][$header->value]['Value']);
				
													$data_coloums[]= $escapedValue;
												}
											}else{
												$data_coloums[]= '';
											} 
										//}
									}
								// $data_coloums[]=$note;
								 $data_coloums[]= $itemid;
								  //var_dump($data_coloums);
								   fputcsv(
									$output,
										$data_coloums
									);  
							}//if confirmed
							
						}//for
						 
					}//foreach
					
			}//if tickets 
			
		}//for item
		exit;	
	}

}

