<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HTML View class for the RseventsCheckin Component
 *
 * @since  0.0.1
 */

use Joomla\CMS\Factory;

require_once JPATH_SITE . '/components/com_rseventspro/helpers/adapter/adapter.php';
require_once JPATH_SITE . '/components/com_rseventspro/helpers/rseventspro.php';
require_once JPATH_ADMINISTRATOR . '/components/com_rsform/helpers/rsform.php';
class RseventsCheckinViewRseventsCheckin extends JViewLegacy
{
	/**
	 * Display the Hello World view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	function display($tpl = null)
	{

		// Assign data to the view
		$app   = Factory::getApplication();
		$layout = $app->input->get('layout', '', 'string');
		$model = $this->getModel();
		 
		$note_column='Subscription_Note' ;
		$this->can_view_subscriptions = 0;
		$this->can_edit_subscriptions = 0;
		$this->can_change_subscriptions = 0;
		$this->can_delete_subscriptions = 0;
		$config =  JComponentHelper::getParams('com_rseventscheckin');
		//some time session expired
		try { 
			$permissions = $model->getPermission();
			foreach ($permissions as $permission) {
				if ($permission->can_view_subscriptions == 1) {
					$can_view_subscriptions = $permission->can_view_subscriptions;
					$this->can_view_subscriptions = $can_view_subscriptions;
				}
				if ($permission->can_edit_subscriptions == 1) {
					$can_edit_subscriptions = $permission->can_edit_subscriptions;
					$this->can_edit_subscriptions = $can_edit_subscriptions;
				}
				if ($permission->can_change_subscriptions == 1) {
					$can_change_subscriptions = $permission->can_change_subscriptions;
					$this->can_change_subscriptions = $can_change_subscriptions;
				}
				if ($permission->can_delete_subscriptions == 1) {
					$can_delete_subscriptions = $permission->can_delete_subscriptions;
					$this->can_delete_subscriptions = $can_delete_subscriptions;
				}
			}
		}catch(Exception $e) {
			 
		}
		$is_name_sorted = $app->input->get('is_name_sorted');
		
		
		$language = JFactory::getLanguage();
		$language->load('com_rseventspro', JPATH_ADMINISTRATOR);
		$_prefix = 'RseventsproModel';
		JModelLegacy::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_rseventspro/models', $_prefix);
		$subscription_model = JModelLegacy::getInstance('Subscription', $_prefix);
		$this->availble_events =	$subscription_model ->getEvents();
		$event_lists=	$model->getEvents();		 
	    $events=$event_lists;
		$this->event_id = JFactory::getApplication()->input->get('filter_event');
		$this->form_id=0;
		foreach ($events as $i => $event) 
		{
			$event_text=isset($event->start)? ' (' . rseventsproHelper::showdate($event->start) . ')':'';
			$events[$i]->text = $event->text . $event_text  ;
			if(!empty($this->event_id) && ($event->value==$this->event_id))
			{
					$this->form_id=$event->form;
			}
		}
		 
		$submission_fields_array=[];
	
		if($this->form_id>0){
			$submission_fields=$config->get('rs_submission_fields');

			$submission_fields_array=explode(',',$submission_fields);
			$submission_fields_array[]=$note_column;
			$submission_fields=$model->checkFormColumns($this->form_id,$submission_fields_array);
			foreach($submission_fields as $submission_field){
				$submission_fields_array[]=$submission_field->ColumnName;
			}
		}
		
		if (empty($is_name_sorted )) {
			if(count($events)>1){
				foreach ($events as $i => $event) 
				{
					if ($event->value > 0) 
					{
						$this->event_id =$event->value ;
						break;
					}
				}

			}else{
				$this->event_id =0;
			}
		}
		 
		$this->events=array_merge(array(JHTML::_('select.option', 0, JText::_('COM_RSEVENTSPRO_SELECT_EVENT'))),$events);
	    $this->total_subscription='0';
		$this->total_hidden_subscription='0';
		$this->total_checked='0';
		$this->total_unchecked='0';
		$this->total_unchecked_tickets='0';
		$this->event_state = JFactory::getApplication()->input->get('filter_state',1);
		if (!empty($this->event_id)) {
			$this->total_subscription=$model->getTotalSubscribers($this->event_id);
			$this->total_hidden_subscription=$model->getTotalSubscribersBYState($this->event_id,0);//unchecked 
		   	$obj= $this->total_unchecked_subscription=$model->getTotalcheckedSubscribers($this->event_id,$this->event_state );//unchecked
			$this->total_checked=$obj->checked;
			$this->total_unchecked=$obj->unchecked; 
			$this->total_unchecked_tickets=$obj->unchecked_tickets;  
			 
		}
		 

		$_prefix = 'RseventsCheckInModel';
		JModelLegacy::addIncludePath(JPATH_SITE . '/components/com_rseventscheckin/models', $_prefix);
		$subscriptions_model = JModelLegacy::getInstance('Subscriptions', $_prefix);
		
		//filter the result by event_id
		 

		$ajax_action = JFactory::getApplication()->input->get('action', '', 'string');

		if ($ajax_action == 'ajax_complete') {
			$confirm_state = JFactory::getApplication()->input->get('confirm');
			$confirm_id = JFactory::getApplication()->input->get('confirm_id');


			$model->updateSubmissionState($confirm_id, $confirm_state);
			//$this->getStatus($confirm_state)
			rseventsproHelper::addLogEntry($confirm_id, 'The status of subscription is set to <strong>'.rseventsproHelper::getStatuses($confirm_state).'</strong> by <strong>'.JFactory::getUser()->get('name').'</strong>.');

			echo "State changed ";
			die;
		}

		if ($ajax_action == 'ajax_confirm') {
			$confirm_states = $app->input->get('confirm');

			$confirm_ids = $app->input->get('confirm_id');
			$codes = $app->input->get('code');
 
			if (is_array($confirm_ids)) {

				$loop = -1;
				foreach ($confirm_ids as $confirm_id) {
					$loop++;
					$code = $codes[$loop];
					$confirm_state = $confirm_states[$loop];
					if ($confirm_state == 'true') {
						$confirm = true;
					} else {
						$confirm = false;
					}
					$model->confirm($confirm_id, $code, $confirm);

					rseventsproHelper::addLogEntry($confirm_id, 'The status of ticket '.$code.' set to <strong>Confirmed</strong> by <strong>'.JFactory::getUser()->get('name').'</strong>.');

				}
			} else {
				if ($confirm_states == 'true') {
					$confirm = true;
					rseventsproHelper::addLogEntry($confirm_ids, 'The status of ticket '.$codes.' set to <strong>Confirmed</strong> by <strong>'.JFactory::getUser()->get('name').'</strong>.');

				} else {
					$confirm = false;
					rseventsproHelper::addLogEntry($confirm_ids, 'The status of ticket '.$codes.' set to <strong>Unconfirmed</strong> by <strong>'.JFactory::getUser()->get('name').'</strong>.');

				}
				$model->confirm($confirm_ids, $codes, $confirm);
			}


			echo "Confirmation State changed";
			die;
		}

		if ($ajax_action == 'ajax_save_note') {
			$message = $app->input->get('message', '', 'string');
			$field_id = $app->input->get('field_id');
			$form_id = $app->input->get('form_id');
			$submission_id = $app->input->get('submission_id');
			if($field_id==0){
				$model->addNote($form_id,$submission_id,$note_column, $message);	
			}else{
				$model->updateNote($field_id, $message);
			}
			
			echo "Note Updated ";
			die;
		}
		
		if ($ajax_action == 'ajax_delete_ticket') {
			 
			$ticket_id = $app->input->get('idt');
			$sid = $app->input->get('sid');
			$ids = $app->input->get('ids');
			$code = $app->input->get('cd');
			$confirm_code_id = $app->input->get('cnf');
			if($ticket_id>0){
				$model->deleteTicket($sid,$ticket_id,$ids,$code, $confirm_code_id);	
			} 
			echo "Ticket Deleted ";
			die;
		}
		if ($ajax_action == 'ajax_save_tickets') {
			 
			$idt = $app->input->get('idt');
			$qty = $app->input->get('qty');
			$ids = $app->input->get('ids');
			$sid = $app->input->get('sid');
			$confirm = $app->input->get('cnf');
			 
			if($qty>0){
				$model->addNewTicket($idt,$qty,$ids,$sid,$confirm);	
			} 
			echo "Ticket Saved ";
			die;
		}

		if ($ajax_action == 'ajax_get_event_tickets')
		{			 
			$eid = $app->input->get('eid');
			$sid = $app->input->get('sid'); 
			$ids = $app->input->get('ids'); 

			$tickets=$model->getTicketsByEventID($eid);	
			 
			include_once(__DIR__).'/tmpl/event_ticket_selector_table.php'; 
			 
			die;
		}

		if (!empty($this->event_state))   {
			$subscriptions_model->setState('filter.state', $this->event_state);
		}
 
		$subscriptions_model->setState('list.direction', 'asc');
		$subscriptions_model->setState('filter.order', 'u.name');
		 
		 
		if (!empty($this->event_id)) {
			$app->input->set('filter_event', $this->event_id);
			$subscriptions_model->setState('filter.event', $this->event_id);
		}

		$subscriptions = [];
		$this->state 		 = $subscriptions_model->getState();
		if($app->input->get('export')==1){
			$subscriptions_model->setState('list.limit',0);
		}
	 
		if (!empty($is_name_sorted ) &&  !empty($this->event_id ) ) {
			$subscriptions =	$subscriptions_model->getItems();
		}

		$submission_ids = [];
		foreach ($subscriptions as   $k=>$item) 
		{
			$submission_ids[] = $item->SubmissionId;
			 
		} 

		$rs_submission_form_id = $config->get('rs_submission_form');
		$this->submission_form_id = $rs_submission_form_id;
		if(!empty($this->form_id)){
			$this->submission_form_id = $this->form_id;
		}
		$this->rs_submission_fields ="";
		$this->rs_submission_field_note ="";
		if(!empty($submission_fields_array)){
			$this->rs_submission_fields = implode(',',$submission_fields_array);
		}
		 if(in_array($note_column,$submission_fields_array)){
			$this->rs_submission_field_note = $note_column;	
		 }
		
		$this->rs_submission_field_ticket = $config->get('rs_submission_field_ticket');
		
		$this->pagination =    $subscriptions_model->getPagination();

		/*$_prefix="RsformModel";
			 JModelLegacy::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_rsform/models', $_prefix);
			$submission_model = JModelLegacy::getInstance('Submissions', $_prefix); 
			 JFactory::getApplication()->input->set('cid', 7); 
			$submission_model->firstFormId=$rs_submission_form;
			$submissions=$submission_model->getSubmissions(); */


		$model->submission_ids = $submission_ids;
		$submissions = $model->getSubmissions($rs_submission_form_id);
		$submissions_tickets=[];
		 
		$this->subscriptions=$subscriptions;
		$header_columns = explode(',', $this->rs_submission_fields);
		$this->header_columns=$header_columns;
		$this->headers 		 = $model->getHeaders($header_columns);
		$this->unescapedFields 		 = $model->getUnescapedFields();
		$this->submissions = $submissions;
		 
		$this->submissions_tickets = $submissions_tickets;

		// Propose current language as default
		if (JLanguageMultilang::isEnabled()) {
			$lang = JFactory::getLanguage()->getTag();
			//$this->form->setFieldAttribute('language', 'default', $lang);
		}

		//$this->filterForm = $app->input->get('FilterForm', 'rseventscheckin', 'filter');
		$this->filterForm    	= $this->get('FilterForm');

		$this->activeFilters 	= $this->get('ActiveFilters');
		if (!empty($this->event_id)) {
			$ticketXml = new SimpleXMLElement('<field name="ticket" type="hidden" default="" />');
			$this->filterForm->setField($ticketXml, 'filter', true);
		}
		// Check that the user has permissions to create a new rseventscheckin record
		$this->canDo = JHelperContent::getActions('com_rseventscheckin');
	 
		if($this->canDo->get('core.create')){
			$this->can_view_subscriptions=1;
			$this->can_edit_subscriptions=1;
			$this->can_change_subscriptions=1;
			$this->can_delete_subscriptions=1;	
		} 
		if ($this->can_view_subscriptions == 0) 
		{
			$app = JFactory::getApplication();
			$app->enqueueMessage(JText::_('JERROR_ALERTNOAUTHOR'), 'error');
			$app->setHeader('status', 403, true);
			return;
		}

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			throw new Exception(implode("\n", $errors), 500);
		}
		if($app->input->get('export')==1){
			$status=$app->input->get('status',1);
			$this->downloadCSV($status);
			exit;
		}
		// Call the parent display to display the layout file
		parent::display($tpl);
		if ($layout == 'table') {
			$app = JFactory::getApplication();
			$app->close();
		}

		// Set properties of the html document
		$this->setJDocument();
	}
	protected function setJDocument()
	{
		$document = JFactory::getDocument();
		$document->setTitle(JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CREATING'));
		// $document->addScript($this->script);
		$document->addStyleSheet(JURI::root() . "/components/com_rseventscheckin"
			. "/views/rseventscheckin/w3.css");
		JText::script('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_ERROR_UNACCEPTABLE');
	}

	protected function getUser($id)
	{
		if ($id > 0)
			return JFactory::getUser($id)->get('username');

		return JText::_('COM_RSEVENTSPRO_GLOBAL_GUEST');
	}

	protected function getStatus($state)
	{
		if ($state == 0) {
			return '<font color="blue">' . JText::_('COM_RSEVENTSPRO_RULE_STATUS_INCOMPLETE') . '</font>';
		} else if ($state == 1) {
			return '<font color="green">' . JText::_('COM_RSEVENTSPRO_RULE_STATUS_COMPLETE') . '</font>';
		} else if ($state == 2) {
			return '<font color="red">' . JText::_('COM_RSEVENTSPRO_RULE_STATUS_DENIED') . '</font>';
		} else if ($state == 3) {
			return '<font color="orange">' . JText::_('COM_RSEVENTSPRO_RULE_STATUS_REFUNDED') . '</font>';
		}
	}
	protected function downloadCSV($status)
		{
			$file_name= ($status==1)?JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CONFIRM_LABEL'):JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_UNCONFIRM_LABEL');
			 
			foreach ($this->subscriptions as $i => $item) 
			{
				$file_name.=" - " .$item->event." - ";;  
				if ($item->allday){  
					$file_name.= rseventsproHelper::showdate($item->start, rseventsproHelper::getConfig('global_date'));  
				  } else  {
					$file_name.=" (". rseventsproHelper::showdate($item->start) ." - ". rseventsproHelper::showdate($item->end) .")";
				  } 
				break; 
			} 
			 
			//ob_clean();
			header('Content-Type: text/csv; charset=utf-8');
			 
			header("Content-Disposition: attachment; filename={$file_name}.csv");
			 
			$output = fopen('php://output', 'w');
			$coloums= [
				'#',
				JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_NAME'),
				JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TICKETS')  ,
				JText::_('COM_RSEVENTSCHECKIN_SUBSCSRIPTION_STATUS'),
				JText::_('COM_RSEVENTSPRO_EVENT_TICKET_PRICE'),
				JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TOTAL') ,
				JText::_('COM_RSEVENTSPRO_SUBSCRIBER_DISCOUNT'),
				JText::_('COM_RSEVENTSPRO_SUBSCRIBER_DISCOUNT_CODE'),
				JText::_('COM_RSEVENTSPRO_SUBSCRIBER_DATE'),
				
			];
			
			
		   foreach ($this->headers as $header) {
					$coloums[]=$header->label;
			}
			//$coloums[]=JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_LABEL');
			$coloums[]=JText::_('JGRID_HEADING_ID');
			 
			 fputcsv($output,$coloums);
			$index=0;
			
			$loop=-1;
		 
			foreach ($this->subscriptions as   $k=>$subscription) 
			{
				$loop++;
				 $submission=[];
				 
			   //if(isset($this->subscriptions[$loop])){

			   	
				$item=$subscription;
				$coupon=$item->coupon;	
				$rsform_submissionId = $item->SubmissionId;
				
				 
				if(!empty($item->SubmissionId)){
					if(isset($this->submissions[$rsform_submissionId])){
						$submission = $this->submissions[$rsform_submissionId];	
					}
				
				} 
				
				$ticket_column = $this->rs_submission_field_ticket;
				//$tickets = $submission['SubmissionValues'][$ticket_column]['Value'];
				$note_column = $this->rs_submission_field_note;
				$note = '';
				$coupon = '';
				$discount = '';
				$tickets = rseventsproHelper::getUserTickets($item->id);
				 
				
					//if($item->state==0 && $status==1){ continue;} 
					$total = rseventsproHelper::total($item->id); 
					$total = $total > 0 ? $total : 0; 
					 $ticket_total=rseventsproHelper::currency($total); 
					 $confirm_status= strip_tags($this->getStatus($item->state));
					if ($tickets) {
						
						foreach ($tickets as $ticket) 
						{
							$coupon =$item->coupon;
							if(!empty($item->discount)){
								$discount =rseventsproHelper::currency($item->discount);
							}
							
							$index_changed=false; 
							for ($j = 1; $j <= $ticket->quantity; $j++) 
							{
                                $confirmed =false;
								
								$ticket_details=  $ticket->name  ;
								$ticket_price=($ticket->price > 0 ? rseventsproHelper::currency($ticket->price) : JText::_('COM_RSEVENTSPRO_GLOBAL_FREE'));
							 
									$code	= md5($item->id.$ticket->id.$j);
									$code	= substr($code,0,4).substr($code,-4);
									$code	= rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-').$item->id.'-'.$code;
									$code   = in_array(rseventsproHelper::getBarcodeOptions('barcode', 'C39'), array('C39', 'C93')) ? strtoupper($code) : $code;
									$confirmed = rseventsproHelper::confirmed($item->id, $code);
									$hasLayout = rseventsproHelper::hasPDFLayout($ticket->layout,$item->SubmissionId);
									
                                if(($confirmed && $status==1) || (!$confirmed && $status==0) )
								{
									 
									$date=rseventsproHelper::showdate($item->date, null, true);
									$state=($status==1)?JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CONFIRM_LABEL'):JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_UNCONFIRM_LABEL');
									$subscriber_name= $item->name;
									$event_details=$item->event;
									$itemid= $item->id;
									 
									  if ($item->allday) { 
										$event_details.= rseventsproHelper::showdate($item->start, rseventsproHelper::getConfig('global_date'));
									  }
									  else {
										$event_details.=" ("  .  rseventsproHelper::showdate($item->start)." - ". rseventsproHelper::showdate($item->end) .")";
									 }  
									 $name=$item->name;
									 if(!isset($subs_array[$itemid])){
										$index++;
										$subs_array[$itemid]=$index; 
									 } 
									 $subindex=$subs_array[$itemid];
									 	
									 $data_coloums=[
										$index,										
										$subscriber_name,
										$ticket_details  ,
										$confirm_status, 
										$ticket_price,
										$ticket_total,
										$discount,
										$coupon,
									 	$date
										   
									 ];
									 foreach ($this->headers as $header) {
										  //if ($header->enabled) { 
											 
												if (isset($submission['SubmissionValues'][$header->value]['Value'])) {
													if (in_array($header->value, $this->unescapedFields)) {
														$data_coloums[]= $submission['SubmissionValues'][$header->value]['Value'];
													} else {
														$escapedValue = $this->escape($submission['SubmissionValues'][$header->value]['Value']);
					
														$data_coloums[]= $escapedValue;
													}
												}else{
													$data_coloums[]= '';
												} 
											//}
										}
									// $data_coloums[]=$note;
									 $data_coloums[]= $itemid;
									  //var_dump($data_coloums);
									   fputcsv(
										$output,
											$data_coloums
										);  
                                }//if confirmed
								
							}//for
							 
						}//foreach
						
				}//if tickets 
				
			}//for item
			exit;	
		}
}
