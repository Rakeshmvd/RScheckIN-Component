<table class="table  table-bordered border-primary"  >
 <thead>
    <tr>
        <th>Ticket</th>
        <th width='60'>Quantity</th>
        <th>confirmed</th>
        <th></th>
    </tr>
 </thead>
 <tbody>
    <?php foreach($tickets as $ticket) { ?>
        <tr class="ticket-<?php echo $ticket->id;  ?>" >
        <td><?php echo $ticket->name . ' (' . ($ticket->price > 0 ? rseventsproHelper::currency($ticket->price) : JText::_('COM_RSEVENTSPRO_GLOBAL_FREE')) . ')';   ?></td>
        <td>
        <select class="quanitity-<?php echo $ticket->id;  ?>" >
            <?php for($i=1;$i<21;$i++){
                echo "<option value='{$i}'>{$i}</option>";
            } ?>

        </select>    
        <!-- <input type='text' class="quanitity" value="1" /> --></td>
        <td><input type='checkbox' class="largerCheckbox  confirm_status-<?php echo $ticket->id;  ?>" checked value="1" /></td>
        <td><button onclick="save_ticket('<?php echo $ticket->id; ?>',<?php echo $ids; ?>,'<?php echo $sid; ?>')"   class="btn btn-info btn-sm "  type="button"><i class="icon-save"></i> Save</button></td>
    </tr>
    <?php } ?>
 </tbody>
 </table>