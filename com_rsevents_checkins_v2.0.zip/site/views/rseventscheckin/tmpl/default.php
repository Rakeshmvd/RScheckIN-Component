<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
$lang = JFactory::getLanguage()->getTag();
if (JLanguageMultilang::isEnabled() && $lang) {
	$query_lang = "&lang={$lang}";
} else {
	$query_lang = "";
}

$listOrder	= $this->escape($this->state->get('list.ordering', ''));

$listDirn	= $this->escape($this->state->get('list.direction', 'desc'));
$select = "$listOrder $listDirn";
$availble_events=[];

foreach ($this->availble_events as $event) {
								if ($event->value == 0) {
									$event->value = '';
									continue;
								}
		$availble_events[]=$event->value ;
	}
	
?>
<style>
	.visually-hidden{ display: none;}
	.table td.box{ position: relative;padding-top: 1.2rem; }
	.ribbon {
	--f: 10px;
	--r: 15px;
	--t: 10px;
	position: absolute;
	inset: var(--t) calc(-1*var(--f)) auto auto;
	padding: 0 10px var(--f) calc(10px + var(--r));
	clip-path: polygon(0 0,100% 0,100% calc(100% - var(--f)),calc(100% - var(--f)) 100%, calc(100% - var(--f)) calc(100% - var(--f)),0 calc(100% - var(--f)), var(--r) calc(50% - var(--f)/2));
	background: #BD1550;
	box-shadow: 0 calc(-1*var(--f)) 0 inset #0005;
	white-space: nowrap;
	font-size: 12px;
	top: 2px;
	color:#fff;
}
</style>
<h2 class="event-title"><?php echo JText::_('COM_RSEVENTSCHECKIN_LEGEND_DETAILS') ?> <i class='preloader d-none fa fa-spinner fa-spin'></i></h2>
<form action="<?php echo JRoute::_('index.php?option=com_rseventscheckin&view=rseventscheckin'); ?>" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">

	<div class="form-horizontal">
		<div class='row  subscribe-addcontainer' <?php if(empty($this->event_id)){ ?>style="display: none;" <?php  }
			if($this->can_edit_subscriptions==1){
		    ?>  >
				<div class="md-12 text-right pt-2">
					<button type="button"  onclick="openSubscriberModal(event)" class="btn float-end  btn-primary btn-sm m-2 btn-subscriber-modal"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_ADD_SUBSCRIBER_LABEL'); ?></button>
 					<button type="button"  onclick="exportInfo(1)" class="btn float-end  btn-secondary btn-sm m-2  ">
				<i class="icon-download"></i> <?php echo JText::_('COM_RSEVENTSCHECKIN_EXPORT_CONFIRMED_CSV') ?>
					<button type="button"  onclick="exportInfo(0)" class="btn float-end  btn-secondary btn-sm m-2">
					<i class="icon-download"></i> <?php echo JText::_('COM_RSEVENTSCHECKIN_EXPORT_UNCONFIRMED_CSV') ?></button>
			 
			</button>
					
				</div><?php } ?>

			</div>
		<fieldset class="adminform">
	
			<div class="d-flex flex-row  justify-content-between">
				<div>
					<div class="js-stools-container-bar">
						<select name="filter_event" class="filter-event-control" id='event_selector'>

							<?php
							foreach ($this->events as $event) {
								/* if ($event->value == 0) {
									$event->value = '';
								} */
							?>
								<option <?php if ($this->event_id == $event->value) { ?> selected <?php } ?> value="<?php echo $event->value; ?>"><?php echo JText::_($event->text); ?></option>
							<?php
							}
							?>

						</select>
					</div>

				</div>
				<div>
					<div class='js-stools-container-bar'>
					<input   type="hidden"   value='1' name='filter_state' />
						 
						<label class="chk hasTooltip " <?php if ($this->event_state == 0) 
						{ ?> 
						title='<?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_UNCHECK_TOOLTIP'); ?>' <?php } else { ?> title='<?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CHECK_TOOLTIP'); ?>' 
						<?php
						}?>>
							<input id='event_state' type="checkbox" <?php if ($this->event_state == 0) { ?> checked <?php } ?> value='0' name='filter_state' />
							<span class="chk-checkmark"></span>
						</label>
					</div>
				</div>
				<div>
					<?php if (!empty($this->filterForm)) {

						echo JLayoutHelper::render(
							'joomla.searchtools.default',
							array('view' => $this)
						);
					}  ?>

				</div>

			</div>

		</fieldset>
	</div>

	<div class="table-response"><?php 
	include_once(__DIR__).'/list.php'; ?>
	</div>
	<input type="hidden" name="task" />
	<input type="hidden" name="is_name_sorted" value="1" />
	<div class="hidden-inputs"></div>
	<?php echo JHtml::_('form.token'); ?>
</form>


<div class="modal modal-lg" tabindex="-1" id="subscriberModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_SUBSCRIBER_HEADING_LABEL'); ?></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<iframe id='subscriberModalFrame' style='width:100%;min-height:450px;overflow-x:hidden' src="<?php  echo JURI::root()  ?> ?>index.php?option=com_rseventspro&layout=subscribe&id=<?php echo  $this->event_id;  ?>&tmpl=component"></iframe>
				<?php // echo RSFormProHelper::displayForm($this->submission_form_id); 
				?>
			</div>
		</div>
	</div>
</div>

<div class="modal" tabindex="-1" id="NoteModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_HEADING_LABEL'); ?></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form>

					<div class="mb-3">
						<label for="message-text" class="col-form-label"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_LABEL'); ?></label>
						<textarea class="form-control" rows="8" name='message' id="message"></textarea>
						<input type='hidden' name='field_id' id="field_id">
						<input type='hidden' name='form_id' id="form_id">
						<input type='hidden' name='submission_id' id="submission_id">
					</div>
				</form>
			</div>
			<div class="modal-footer">

				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_CLOSE_LABEL'); ?></button>
				<?php if ($this->can_edit_subscriptions == 1) { ?>
					<button type="button" class="btn btn-primary" onclick="saveNote()"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_SAVE_LABEL'); ?></button>
				<?php } ?>

			</div>
		</div>
	</div>
</div>

<script>

	var NoteModal = document.getElementById('NoteModal')
	

	NoteModal.addEventListener('show.bs.modal', function(event) {
		// Button that triggered the modal
		var button = event.relatedTarget
		// Extract info from data-bs-* attributes
		var recipient = button.getAttribute('data-bs-whatever')
		var data_note = button.getAttribute('data-note')
		note_value = '';
		var note_field_id = button.getAttribute('data-noteid');
		if (data_note == 1) {
			note_value = button.parentNode.querySelector('.note-container').innerHTML;

		}
		var note_form_id = button.getAttribute('data-formid');
		var note_submission_id = button.getAttribute('data-submissionid'); 
		// If necessary, you could initiate an AJAX request here
		// and then do the updating in a callback.
		//
		// Update the modal's content.
		var modalTitle = NoteModal.querySelector('.modal-title')
		var modalBodyInput = NoteModal.querySelector('.modal-body #message')
		var modalBodyInput2 = NoteModal.querySelector('.modal-body #field_id')
		var modalBodyInput3 = NoteModal.querySelector('.modal-body #form_id')
		var modalBodyInput4 = NoteModal.querySelector('.modal-body #submission_id')
		//modalTitle.textContent = 'New message to ' + recipient
		modalBodyInput.value = note_value
		modalBodyInput2.value = note_field_id
		modalBodyInput3.value = note_form_id
		modalBodyInput4.value = note_submission_id
	})

	jQuery(document).ready(function($) {
		var resetTimeout=null;
		var modal_status_changed=false;
		var availble_events =<?php echo json_encode($availble_events); ?>;
		openSubscriberModal = function(e) {
			e.preventDefault()
			modal_status_changed=true;
			jQuery('#subscriberModal').modal('show')
		}
		
		saveNote = function() {

			ajaxurl = window.location.href;
			message = jQuery('#NoteModal').find('.modal-body #message').val()
			
			field_id = jQuery('#NoteModal').find('.modal-body #field_id').val()
			form_id = jQuery('#NoteModal').find('.modal-body #form_id').val()
			submission_id = jQuery('#NoteModal').find('.modal-body #submission_id').val()
			var data = {
				'action': 'ajax_save_note',
				'message': message,
				'field_id': field_id,
				'form_id': form_id,
				'submission_id': submission_id

			};
			 
			jQuery('.preloader').removeClass('d-none')	
			jQuery.post(ajaxurl, data)
				.done(function(response) {
					modal_status_changed=true;
					var modal = bootstrap.Modal.getInstance(NoteModal);
					
					modal.hide();
					jQuery('.note-container-'+submission_id).html(message)
				jQuery('.note_'+submission_id).html(message)
					jQuery('.preloader').addClass('d-none')

				});

		}
		 
		toggleComplete = function(elem, confirm_id) {
			jQuery('.preloader').removeClass('d-none')
			//modal.hide();
			confirm = elem.val();

			ajaxurl = window.location.href;
			var data = {
				'action': 'ajax_complete',
				'confirm': confirm,
				'confirm_id': confirm_id
			};

			jQuery.post(ajaxurl, data)
				.done(function(response) {
					jQuery('.preloader').addClass('d-none')
					modal_status_changed=true;
				});

		}
		toggleConfirmation = function(confirm_id, code, elem, ticket_id) {
			confirm_status = elem.prop('checked')
			prev_unconfirm = jQuery('#ticketModal_' + confirm_id).find('.chk-unconfirm').length
			jQuery('.preloader').removeClass('d-none')
			ajaxurl = window.location.href;
			var data = {
				'action': 'ajax_confirm',
				'confirm': confirm_status,
				'code': code,
				'confirm_id': confirm_id
			};

			jQuery.post(ajaxurl, data)
				.done(function(response) {
					jQuery('.preloader').addClass('d-none')
					modal_status_changed=true;
				});

		}


		toggleConfirmationAll = function(id) {
			btn = jQuery('#btn_ticket_first_' + id)
			confirm_ids = [];
			confirm_statuss = [];
			codes = [];
			if (jQuery('#ticketModal_' + id).find('.chk-unconfirm').length > 0)
			{
				modal_status_changed=true;
				jQuery('#ticketModal_'+id).find('.chk-unconfirm').each(function(){
					id=jQuery(this).val();
	
					code=jQuery(this).attr('data-code');
					confirm_ids.push(id);
					confirm_statuss.push(true);
					codes.push(code);
					 
				})  

				ajaxurl = window.location.href;
				var data = {
					'action': 'ajax_confirm',
					'confirm': confirm_statuss,
					'code': codes,
					'confirm_id': confirm_ids
				};
				jQuery.post(ajaxurl, data)
					.done(function(response) {
						  resetTimeout = setTimeout(reset_table, 1);
						 
					});
			}
		}

		setUpModelReset=function(){
			jQuery('body').find('.modal').each(function() {
				 elem_id=jQuery(this).attr('id');
				jQuery(this).on("hidden.bs.modal", function () {
					reset_table()
				})  
			})
		}

		jQuery('#event_selector').on('change', function() {	
			modal_status_changed=true;		 
			reset_table()
		})

		jQuery('#event_state').on('change', function() {		
			modal_status_changed=true;	 
			reset_table()
		})

		pagination_click = function(e) {
			e.preventDefault();
			url = jQuery(this).attr('href')
			 
			data = {};
			jQuery('.preloader').removeClass('d-none')
			jQuery.get(url, data)
				.done(function(response) {
					jQuery('.table-response').html(response)
					/*    */
					jQuery('.preloader').addClass('d-none')
					jQuery('.table-response').find('.page-link').on('click', pagination_click);
					setUpModelReset();
					jQuery('.table-response').find('.js-stools-column-order').on('click',function(){
							 
							 order=jQuery(this).data("order")
							 dir=jQuery(this).data("direction")
							  jQuery('#list_fullordering').val(order+' '+ dir)
							  jQuery('#list_fullordering').trigger('change')
					});
					
				})
		}


		get_tickets=function(event_id,ids,sid)
		{
			jQuery('#ticketModal_'+ids).find('.new-ticket-response').show()
			
			var data = {
					'action': 'ajax_get_event_tickets',
					'eid': event_id,
					'ids': ids,
					'sid': sid,
				};
			 
				jQuery('.preloader-add-ticket').removeClass('d-none')	
				jQuery.post(ajaxurl, data)
					.done(function(response) {
						jQuery('#ticketModal_'+ids).find('.new-ticket-response').html(response)
						jQuery('#ticketModal_'+ids).find('.btn-add-ticket').addClass('d-none')
						jQuery('#ticketModal_'+ids).find('.btn-cancel-ticket').removeClass('d-none')
						//jQuery('#ticketModal_'+itemid).find('.table-confirmed-tickets').addClass('d-none')
						jQuery('.preloader-add-ticket').addClass('d-none')

					}); 
			 
		}



		cancel_tickets=function(itemid)
		{
			 
			jQuery('#ticketModal_'+itemid).find('.new-ticket-response').html("")
			jQuery('#ticketModal_'+itemid).find('.btn-add-ticket').removeClass('d-none')
			jQuery('#ticketModal_'+itemid).find('.btn-cancel-ticket').addClass('d-none')
			//jQuery('#ticketModal_'+itemid).find('.table-confirmed-tickets').removeClass('d-none') 
		}

		save_ticket=function(idt,ids,sid)
		{

			  var data = {
					'action': 'ajax_save_tickets',
					'idt': idt,
					'ids': ids,
					'sid': sid,
					'qty':jQuery('#ticketModal_'+ids).find('.ticket-'+idt).find('.quanitity-'+idt).val(),
					'cnf': jQuery('#ticketModal_'+ids).find('.ticket-'+idt).find('.confirm_status-'+idt).prop('checked')

				};
			   
				jQuery('.preloader').removeClass('d-none')	
				jQuery.post(ajaxurl, data)
					.done(function(response) {
						 
						modal_status_changed=true;	 
						jQuery('.preloader').addClass('d-none')

					});  

		}
		delete_ticket=function(e,sid,idt,ids,code,confirm_id,tindex)
		{
			can_delete=true;
			jQuery('#ticketModal_'+ids).find('.btn-delete-ticket-'+idt).each(function(){
				ticket_index=jQuery(this).data('index');
				if(ticket_index>parseInt(tindex)){
					can_delete=false;
				}
			})
			
			if(!can_delete){
				alert('<?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_DELETE_TICKET_SEQUENCE_ERROR'); ?>')
				return false;	
			}
			
			
            if(can_delete && confirm("<?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_DELETE_TICKET_CONFIRM_MESSAGE'); ?>"))
			{ 

			  var data = {
					'action': 'ajax_delete_ticket',
					'idt': idt,
					'ids': ids,
					'sid':sid,
					'cd': code,
					'cnf': confirm_id 

				};
			 
				jQuery('.preloader').removeClass('d-none')	
				jQuery.post(ajaxurl, data)
					.done(function(response) {
						jQuery('#ticketModal_'+ids).find('.ticket-row-'+code).remove()
						modal_status_changed=true;	 
						jQuery('.preloader').addClass('d-none')

					}); 
			}
		 

		}


		exportInfo=function(status) {
			eventid = jQuery('#event_selector').val()
			filter_state=0;
			if(jQuery('filter_state').prop('checked')){
				filter_state=1;
			}
			window.location.href='<?php echo JRoute::_('index.php?option=com_rseventscheckin&view=rseventscheckin&export=1&is_name_sorted=1');?>&filter_state='+filter_state+'&status='+status+'&filter_event='+eventid ;

		}
		reset_table = function() {
			
			jQuery('.table-response').find('.event-title-box').addClass('d-none')
			if(modal_status_changed){
				if(resetTimeout){
					clearTimeout(resetTimeout); 
				}
				jQuery('.preloader').removeClass('d-none')
				eventid = jQuery('#event_selector').val()
			
				event_title = "";
				if (eventid > 0) {
					event_title = jQuery("#event_selector option:selected").text()
					jQuery('.subscribe-addcontainer').show()
					jQuery('.btn-subscriber-modal').hide()
					$.each(availble_events, function(index, availble_event_id) {
						 
                    if (availble_event_id == eventid ) {
                        iframe = "<iframe onload=\"jQuery('.btn-subscriber-modal').show()\"  style='width:100%;min-height:450px;overflow-x:hidden' src='<?php echo JURI::root()  ?>index.php?option=com_rseventspro&layout=subscribe&id="+eventid+"&tmpl=component'></iframe>";
						jQuery('#subscriberModal').find('.modal-body').html(iframe)
                    }
                });
					//jQuery('.subscribe-addcontainer').show()
										} 

				ajaxurl = window.location.href;

				jQuery('.hidden-inputs').append("<input type='hidden' name='layout' value='table' />")
				jQuery('.hidden-inputs').append("<input type='hidden' name='tmpl' value='component' />")
				data = jQuery('#adminForm').serialize()
				jQuery('.hidden-inputs').html('')
				jQuery.get(ajaxurl, data)
					.done(function(response) {
						jQuery('.table-response').html(response)
						jQuery('.table-response').find('.js-stools-column-order').on('click',function(){
							 order=jQuery(this).data("order")
							 dir=jQuery(this).data("direction")
							  jQuery('#list_fullordering').val(order+' '+ dir)
							  jQuery('#list_fullordering').trigger('change')
						});  
						jQuery('.preloader').addClass('d-none')
						jQuery('.table-response').find('.page-link').on('click', pagination_click)
						setUpModelReset();
						jQuery('.table-response').find('.event-title-box').removeClass('d-none')
						jQuery('.table-response').find('.event-title-box').html("<h5 class='text-primary'>"+event_title+"</h5")
						modal_status_changed=false;
					});
			}
			
		}

		<?php if (empty(JFactory::getApplication()->input->get('is_name_sorted'))) { ?>
			jQuery('#list_fullordering').val('u.name ASC')
			modal_status_changed=true;
			reset_table();
			
		
		<?php } ?> 
	 
		jQuery('.table-response').find('.page-link').on('click', pagination_click)

		

	});

	
</script>