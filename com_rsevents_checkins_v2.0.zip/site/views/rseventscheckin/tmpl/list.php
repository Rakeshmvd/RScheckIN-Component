<div class="card mb-3">
	<div class="card-body">
		<div class="p-2 border mx-2 d-inline-block mb-2">
			<span class="badge bg-success rounded-pill"><?php echo $this->total_checked ?></span>
			<span class="text-success">
				<?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_TOTAL_CHECKED_LABEL'); ?></span>
		</div>
		<div class="p-2 border mx-2 d-inline-block mb-2">
			<span class="badge bg-danger rounded-pill"><?php echo $this->total_unchecked ?></span>
			<span class="text-danger">
				<?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_TOTAL_UNCHECKED_LABEL'); ?></span>

		</div>
		<div class="p-2 border mx-2 d-inline-block mb-2">
			<span class="badge bg-danger rounded-pill"><?php echo $this->total_unchecked_tickets ?></span>
			<span class="text-danger"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_TOTAL_UNCHECKED_TICKETS_LABEL'); ?></span>
		</div>
		<?php if ($this->event_state == 1) {   ?>
			<div class="p-2 border mx-2 d-inline-block mb-2">
				<span class="badge bg-dark rounded-pill"><?php echo $this->total_hidden_subscription ?></span>
				<span class="text-dark">
					<?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_TOTAL_HIDDEN_LABEL'); ?></span>

			</div>
		<?php  } ?>

		<div class="p-2 border mx-2 d-inline-block mb-2">
			<span class="badge bg-primary rounded-pill"><?php echo $this->total_subscription; ?></span>
			<span class="text-primary"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_TOTAL_SUBSCRIBER_LABEL'); ?></span>
		</div>

	</div><!-- card-body -->
</div>
<div class="card mb-3">
	<div class="card-body event-title-box">
	</div>
</div>


<table class="table  table-bordered" id="itemList">
	<thead>
		<?php //if ($this->can_change_subscriptions == 1) {   
		?>
		<th width="1%" class="small  <?php echo RSEventsproAdapterGrid::styles(array('center')); ?>">&nbsp;</th>
		<?php //} 
		?>

		<th><?php echo JHtml::_('searchtools.sort', 'COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_NAME', 'u.name', $listDirn, $listOrder); ?></th>
		<?php if (empty($this->event_id)) {  ?>
			<th width="15%" class="d-none d-sm-table-cell nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?>"><?php echo JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_EVENT'); ?></th>
		<?php   } ?>
		<th width="15%" class="nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">
			<?php echo JHtml::_('searchtools.sort', 'COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TICKETS', 'ticket', $listDirn, $listOrder); ?>

		</th>
		<th width="15%" class="nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone"><?php echo JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_TOTAL'); ?></th>
		<?php
		$HAS_NOTE_COLUMN = false;
		foreach ($this->headers as $header) {
			if (!in_array($header->value, $this->header_columns)) {
				continue;
			}
		?>
			<th <?php if (!$header->enabled) { ?>style="display: none" <?php } ?> class="title d-none d-sm-table-cell ">
				<?php
				if ($header->label == 'Subscription_Note') {
					$HAS_NOTE_COLUMN = true;
					echo JHtml::_('searchtools.sort', 'COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_LABEL', 'Subscription_Note', $listDirn, $listOrder);
				} else {

					echo   $header->label;
				}

				?>
			</th>
		<?php
		}

		if ($HAS_NOTE_COLUMN) { ?>
			<th width="1%" class="nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone"> </th>

		<?php

		}
		?>

		<th class="nowrap <?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">

			<?php echo JHtml::_('searchtools.sort', 'JGRID_HEADING_ID', 'u.id', $listDirn, $listOrder); ?>
		</th>
	</thead>
	<tbody id="rseprocontainer">
		<?php
		$loop = -1;

		foreach ($this->subscriptions as   $k => $subscription) {
			$loop++;
			$submission = [];

			//if(isset($this->subscriptions[$loop])){


			$item = $subscription;
			$rsform_submissionId = $item->SubmissionId;

			$discount =  '';
			if ($item->discount > 0) {
				$discount = " <span class='ribbon'> - " . rseventsproHelper::currency($item->discount) . "</span>";
			}

			if (!empty($item->SubmissionId)) {
				if (isset($this->submissions[$rsform_submissionId])) {
					$submission = $this->submissions[$rsform_submissionId];
				}
			}

			$ticket_column = $this->rs_submission_field_ticket;
			//$tickets = $submission['SubmissionValues'][$ticket_column]['Value'];
			$note_column = $this->rs_submission_field_note;
			$note = '';
			$note_field_id = 0;
			if (!empty($submission)) {
				if (isset($submission['SubmissionValues'][$note_column]['Value']))
					$note = $submission['SubmissionValues'][$note_column]['Value'];
				if (isset($submission['SubmissionValues'][$note_column]['Id']))
					$note_field_id = $submission['SubmissionValues'][$note_column]['Id'];
			}

			$tickets = rseventsproHelper::getUserTickets($item->id);

			$has_unconfirmed_tickets = false;

			$purchasedtickets = '';
			$first_box_inputs = '';
			if ($tickets) {
				$ticket = $tickets[0];

				$btn_color = 'btn-primary';

				$btn_text_color = '';
				if ($item->state == '0') {
					$btn_color = ' btn-light ';
					$btn_text_color = 'text-dark';
				}

				if (count($tickets) == 1) {
					$btn_color .= ' d-none ';
				}
				$purchasedtickets .= "<button type='button' id='btn_ticket_{$item->id}' 
						 data-bs-toggle='modal' data-bs-target='#ticketModal_{$item->id}'  
						 class='btn  $btn_color btn-sm'><span class='badge $btn_text_color'> * </span></button> ";
				$ticket_total_quantity = 0;
				$is_multiple = false;
				$check_ticket_name = $ticket->name;
				$is_multiple_ticket = 0;

				foreach ($tickets as $lticket) {

					$ticket_total_quantity += $lticket->quantity;
					if ($check_ticket_name != $lticket->name) {
						$is_multiple_ticket++;
						$check_ticket_name = $lticket->name;
					}
				}

				if ($ticket_total_quantity > 1) {
					$purchasedtickets .= '<span class="text-info">' . $ticket_total_quantity . 'x </span>';
				}

				if ($is_multiple_ticket > 0) {
					$purchasedtickets .=  ' tickets';
				} else {
					$purchasedtickets .=   $ticket->name;
				}

				$first_box_inputs = '';
				$purchasedtickets .=setup_ticket_model($item,$this->can_change_subscriptions);

				$purchasedtickets .= '<div class="table-confirmed-tickets-response">';
				$purchasedtickets .= '<table class="table table-bordered mt-2 table-confirmed-tickets ">';
				$purchasedtickets .= '<thead>';

				$purchasedtickets .= '<tr>';

				$purchasedtickets .= '<th>' . JText::_('COM_RSEVENTSPRO_SUBSCRIBER_TICKET') . '</th>';
				if ($item->state == 1) {

					$purchasedtickets .= '<th class="' . RSEventsproAdapterGrid::styles(array('center')) . '">' . JText::_('COM_RSEVENTSPRO_SUBSCRIBER_TICKET_PDF_CODE') . '</th>';
					$purchasedtickets .= '<th class="' . RSEventsproAdapterGrid::styles(array('center')) . '">' . JText::_('COM_RSEVENTSPRO_SUBSCRIBER_TICKET_PDF_CONFIRMED') . '</th>';
				}
				$purchasedtickets .= '<td  >&nbsp;</td>';
				$purchasedtickets .= '</tr>';
				$purchasedtickets .= '</thead>';

				foreach ($tickets as $ticket) {
					for ($j = 1; $j <= $ticket->quantity; $j++) {
							//if ( $item->state == 1)
						//{
						$code	= md5($item->id . $ticket->id . $j);
						$code	= substr($code, 0, 4) . substr($code, -4);
						$code	= rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-') . $item->id . '-' . $code;
						$code   = in_array(rseventsproHelper::getBarcodeOptions('barcode', 'C39'), array('C39', 'C93')) ? strtoupper($code) : $code;
						$confirmed = rseventsproHelper::confirmed($item->id, $code);
						$hasLayout = rseventsproHelper::hasPDFLayout($ticket->layout, $item->SubmissionId);
						
						
						$purchasedtickets .= '<tr class="ticket-row-' . $ticket->id . ' ticket-row-' . $code . '" >';
						$purchasedtickets .= '<td>' . $ticket->name . ' (' . ($ticket->price > 0 ? rseventsproHelper::currency($ticket->price) : JText::_('COM_RSEVENTSPRO_GLOBAL_FREE')) . ')</td>';
					
						$purchasedtickets .= '<td class="' . RSEventsproAdapterGrid::styles(array('center')) . '">' . ($ticket->id ? $code : '-') . '</td>';
						$purchasedtickets .= '<td class="' . RSEventsproAdapterGrid::styles(array('center')) . '">';
						//	$purchasedtickets .= $ticket->id ? ($confirmed ? '<span class="label label-success">'.JText::_('JYES').'</span>' : '<span><a href="javascript:void(0)" class="label '.rseventsproHelper::tooltipClass().'" title="'.rseventsproHelper::tooltipText(JText::_('COM_RSEVENTSPRO_SUBSCRIBER_TICKET_PDF_CONFIRMED_DESC')).'" onclick="rsepro_confirm_ticket(\''.$item->id.'\',\''.$code.'\', this)">'.JText::_('JNO').'</a></span>') : '-';
						$click = ' disabled ';

						if ($this->can_change_subscriptions == 1) {
							$click = 'onclick="toggleConfirmation(\'' . $item->id . '\',\'' . $code . '\', jQuery(this),\'' . $ticket->id . '\')"';
						}
						if ($item->state != 1) {
							$click = ' disabled ';
						}
						$purchasedtickets .= $ticket->id ? ($confirmed ? '<input type="checkbox" class="largerCheckbox chk-confirm chk-ticket-' . $ticket->id . '" ' . $click . ' checked="checked"  data-code="' . $code . '" value="' . $item->id . '">' : '<input type="checkbox" class="largerCheckbox chk-unconfirm chk-ticket-' . $ticket->id . '"  title="' . rseventsproHelper::tooltipText(JText::_('COM_RSEVENTSPRO_SUBSCRIBER_TICKET_PDF_CONFIRMED_DESC')) . '" data-code="' . $code . '" ' . $click . ' value="' . $item->id . '">') : '-';
						if (!$confirmed)
							$has_unconfirmed_tickets = true;

						$purchasedtickets .= '</td>';
						$purchasedtickets .= '<td ><button data-index="' . $j . '" onclick="delete_ticket(event,\'' . $item->SubmissionId . '\',\'' . $ticket->id . '\',\'' . $item->id . '\',\'' . $code . '\',\'' . $confirmed . '\',' . $j . ')"  title="' . JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_DELETE_TICKET_LABEL') . '" class="btn btn-danger btn-sm btn-delete-ticket btn-delete-ticket-' . $ticket->id . '"  type="button" > <i class="fa-solid fa-trash"></i> </button></td>';
						//}
						$purchasedtickets .= '</tr>';
					}
				}

				$purchasedtickets .= '</table>';
				$purchasedtickets .= '</div>
								</div>
							</div>
						</div>';
			}

			if ($tickets && count($tickets) == 1) {


				//if ( $item->state == 1) {
				$j = 1;

				$ticket = $tickets[0];
				$code	= md5($item->id . $ticket->id . $j);
				$code	= substr($code, 0, 4) . substr($code, -4);
				$code	= rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-') . $item->id . '-' . $code;
				$code   = in_array(rseventsproHelper::getBarcodeOptions('barcode', 'C39'), array('C39', 'C93')) ? strtoupper($code) : $code;
				$confirmed = rseventsproHelper::confirmed($item->id, $code);
				$hasLayout = rseventsproHelper::hasPDFLayout($ticket->layout, $item->SubmissionId);

				//$first_box_inputs .= $ticket->id ? ($confirmed ? '<input type="checkbox" class="largerCheckbox chk-confirm chk-ticket-' . $ticket->id . '" checked="checked" onclick="toggleConfirmation(\'' . $item->id . '\',\'' . $code . '\', jQuery(this),\'' . $ticket->id . '\')" data-code="' . $code . '" value="' . $item->id . '">' : '<input type="checkbox" class="largerCheckbox chk-unconfirm chk-ticket-' . $ticket->id . '"  title="' . rseventsproHelper::tooltipText(JText::_('COM_RSEVENTSPRO_SUBSCRIBER_TICKET_PDF_CONFIRMED_DESC')) . '" data-code="' . $code . '" onclick="toggleConfirmation(\'' . $item->id . '\',\'' . $code . '\', jQuery(this),\'' . $ticket->id . '\')" value="' . $item->id . '">') : '-';
				//$first_box_inputs=  '<input type="checkbox" class="largerCheckbox hasTooltip"  title="'.rseventsproHelper::tooltipText(JText::_('COM_RSEVENTSPRO_SUBSCRIBER_TICKET_PDF_CONFIRMED_DESC')).'" onclick="toggleConfirmation(\''.$item->id.'\',\''.$code.'\',   jQuery(this),\''.$ticket->id.'\')" value="'.$item->id.'">'  ;

				$color = ' btn-light';
				$icon = '<span class="badge text-dark">X</span>';
				$confirm_status = 'Incomplete';
				$click = "";
				/* if(!$confirmed   ){
						
					} */
				//if ($item->state == '1'  && !$has_unconfirmed_tickets) {
				if (!$confirmed) {
					$color = 'btn-danger';
					$icon = '<span class="badge"> &#10003</span>';
					$confirm_status = strip_tags($this->getStatus($item->state));
					$click = "  onclick=\"jQuery('#btn_ticket_{$item->id}').removeClass('d-none');jQuery('#btn_ticket_{$item->id}').trigger('click');jQuery('#btn_ticket_{$item->id}').addClass('d-none');\"   ";
					if ($this->can_change_subscriptions == 1 && $item->state == 1) {
						$click = " onclick='toggleConfirmationAll({$item->id})' ";
					}
				} else {
					$color = 'btn-success';
					$icon = '<span class="badge"> &#10003;</span>';
					$confirm_status = 'Confirmed';
					$click = " onclick=\"jQuery('#btn_ticket_{$item->id}').removeClass('d-none');jQuery('#btn_ticket_{$item->id}').trigger('click');jQuery('#btn_ticket_{$item->id}').addClass('d-none');\"  ";
				}

				$first_box_inputs .= "<button type='button'   title='" . rseventsproHelper::tooltipText($confirm_status) . "'  id='btn_ticket_first_{$item->id}' 
					  modal-target='#ticketModal_{$item->id}'  {$click}
					class='hasTooltip btn {$color} btn-sm '>$icon</button> ";

				/* }else{
						$color=' btn-light';
					$icon='<span class="badge text-dark">X</span>';
					$confirm_status='Incomplete';
					$click = " onclick=\"jQuery('#btn_ticket_{$item->id}').removeClass('d-none');jQuery('#btn_ticket_{$item->id}').trigger('click');jQuery('#btn_ticket_{$item->id}').addClass('d-none');\"  ";

					$first_box_inputs= "
						<button type='button'   title='".rseventsproHelper::tooltipText($confirm_status)."'  id='btn_ticket_first_{$item->id}' 
					  modal-target='#ticketModal_{$item->id}'  {$click}
					class='hasTooltip btn {$color} btn-sm '>$icon</button>";

						
						//$first_box_inputs.=<input type="checkbox"  class="largerCheckbox " onclick="toggleComplete(jQuery(this))" value="'.$item->id.'">'; 
					} */
			} else {

				$btn_color = 'btn-primary';

				$btn_text_color = '';
				if ($item->state == '0') {
					$btn_color = ' btn-light ';
					$btn_text_color = 'text-dark';
				}

				if (count($tickets) == 1) {
					$btn_color .= ' d-none ';
				}
				$purchasedtickets .= "<button type='button' id='btn_ticket_{$item->id}' 
						 data-bs-toggle='modal' data-bs-target='#ticketModal_{$item->id}'  
						 class='btn  $btn_color btn-sm'><span class='badge $btn_text_color'> * </span></button> ";
				$purchasedtickets .= "<span style='visibility:hidden'>0 x tickets</span>";		 
				$purchasedtickets .=setup_ticket_model($item,$this->can_change_subscriptions);
				$color = ' btn-light';
				$icon = '<span class="badge text-dark">X</span>';
				$confirm_status = 'Incomplete';
				$click = "";
				if ($has_unconfirmed_tickets) {
					$color = 'btn-danger';
					$icon = '<span class="badge">&#10003</span>';
					$confirm_status = strip_tags($this->getStatus($item->state));
					$click = " onclick=\"jQuery('#btn_ticket_{$item->id}').removeClass('d-none');jQuery('#btn_ticket_{$item->id}').trigger('click');\" ";
					if ($this->can_change_subscriptions == 1 && $item->state == 1) {
						$click = " onclick='toggleConfirmationAll({$item->id})' ";
					}
				}
				//if ($item->state == '1'  && !$has_unconfirmed_tickets) {
				if (!$has_unconfirmed_tickets) {
					$color = 'btn-success';
					$icon = '<span class="badge">&#10003;</span>';
					$confirm_status = 'Confirmed';
					$click = " onclick=\"jQuery('#btn_ticket_{$item->id}').removeClass('d-none');jQuery('#btn_ticket_{$item->id}').trigger('click');\"  ";
				}
				$first_box_inputs = "<button type='button'   title='" . rseventsproHelper::tooltipText($confirm_status) . "'  id='btn_ticket_first_{$item->id}' 
					  modal-target='#ticketModal_{$item->id}'  {$click}
					class='hasTooltip btn {$color} btn-sm '>$icon</button> ";
			}
		?>

			<tr class="row<?php echo $loop % 2;
							if ($item->state == '0') {
								echo  ' bg-secondary text-light ';
							}
							if ($item->state == '2') {
								echo  ' bg-dark text-light ';
							}
							if ($item->state == '3') {
								echo  ' bg-light ';
							}

							?>  ">
				<?php //if ($this->can_change_subscriptions == 1) {   
				?>
				<td class="largerCheckbox <?php echo RSEventsproAdapterGrid::styles(array('center')); ?>">
					<?php echo $first_box_inputs; ?>
				</td>
				<?php // } 
				?>
				<!-- <td  >
						<input type="checkbox" class="largerCheckbox" value="1" <?php if ($item->state == 1) { ?> checked ='checked' <?php } ?>  />
						
					</td> -->

				<td class="nowrap has-context show_pointer" onclick="jQuery('#ticketModal_<?php echo $item->id ?>').modal('show')">
					<button class="btn btn-link <?php if ($item->state == '2'  || $item->state == '0') {
													echo  'text-light ';
												} ?>" type="button"><?php echo $item->name; ?></button><br />
					<?php echo rseventsproHelper::showdate($item->date, null, true); ?> <br />
				</td>
				<?php if (empty($this->event_id)) {  ?>
					<td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> nowrap has-context d-none d-sm-table-cell">
						<a href="<?php echo JRoute::_('index.php?option=com_rseventspro&task=event.edit&id=' . $item->ide); ?>"><?php echo $item->event; ?></a> <br />
						<?php if ($item->allday) { ?>
							<?php echo rseventsproHelper::showdate($item->start, rseventsproHelper::getConfig('global_date')); ?>
						<?php } else { ?>
							(<?php echo rseventsproHelper::showdate($item->start); ?> - <?php echo rseventsproHelper::showdate($item->end); ?>)
						<?php } ?>
					</td>
				<?php } ?>
				<td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?>  hidden-phone">
					<?php echo $purchasedtickets; 	?>
				</td>
				<td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> box hidden-phone">

					<?php $total = rseventsproHelper::total($item->id); ?>
					<?php $total = $total > 0 ? $total : 0; ?>
					<?php echo rseventsproHelper::currency($total) . $discount; ?>
				</td>

				<?php
				foreach ($this->headers as $header) {
					if (!in_array($header->value, $this->header_columns)) {
						continue;
					}
				?>
					<td class="d-none d-sm-table-cell <?php if ($header->label == 'Subscription_Note') {
															echo "note_{$item->SubmissionId}";
														} ?>" <?php if (!$header->enabled) { ?>style="display: none" <?php } ?>>
						<?php
						if (isset($submission['SubmissionValues'][$header->value]['Value'])) {
							if (in_array($header->value, $this->unescapedFields)) {
								echo $submission['SubmissionValues'][$header->value]['Value'];
							} else {
								$escapedValue = $this->escape($submission['SubmissionValues'][$header->value]['Value']);

								if (isset($this->form->TextareaNewLines) && !empty($this->specialFields['textareaFields']) && in_array($header->value, $this->specialFields['textareaFields'])) {
									$escapedValue = nl2br($escapedValue);
								}

								echo $escapedValue;
							}
						}
						?>
					</td>
				<?php
				}

				if ($HAS_NOTE_COLUMN) {
				?>

					<td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">
						<?php
						if (!empty($item->SubmissionId)) {  ?>
							<i data-bs-toggle="modal" data-formid="<?php echo $this->form_id; ?>" data-submissionid="<?php echo $rsform_submissionId; ?>" data-noteid="<?php echo $note_field_id; ?>" data-note="<?php if (!empty($note)) { ?>1<?php } ?>" data-bs-target="#NoteModal" class="btn note-opener note-opener-<?php echo $note_field_id;
																																																																															if ($item->state == '0') {
																																																																																echo $btn_text_color = ' text-light ';
																																																																															} ?> fa fa-file 
							<?php if (!empty($note)) { ?> has-note text-success <?php } ?>"></i>
						<?php
						} else { ?>
							<i class="<?php echo $btn_text_color = ' text-grey ';  ?> fa fa-file "></i> <?php
																									} ?>
						<div class="d-none note-container note-container-<?php echo $item->SubmissionId; ?>"><?php echo $note; ?></div>

					</td>
				<?php } ?>
				<td class="<?php echo RSEventsproAdapterGrid::styles(array('center')); ?> hidden-phone">
					<?php echo (int) $item->id; ?>
				</td>
			</tr>
		<?php
			//}
		} ?>
	</tbody>
	<tfoot>
		<tr>
			<td colspan="<?php if (!empty($this->event_id)) {
								echo "10";
							} else {
								echo "11";
							} ?>" style="text-align: center;">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
</table>
<?php function setup_ticket_model($item,$can_change_subscriptions)
{
	$purchasedtickets = "";
	$click = ' readonly=readonly  ';
	if ($can_change_subscriptions == 1) {
		$click = "onchange='toggleComplete(jQuery(this),{$item->id})' ";
	}
	$status_select = "<select {$click}  >";
	$selected = '';
	if ($item->state == 0) {
		$selected = 'selected="selected"';
	} else {
		$selected = '';
	}


	if ($can_change_subscriptions == 0) {
		$selected .= ' disabled ';
	}

	$status_select .= "<option {$selected} value='0'>" . JText::_('COM_RSEVENTSPRO_RULE_STATUS_INCOMPLETE') . "</option>";
	if ($item->state == 1) {
		$selected = 'selected="selected"';
	} else {
		$selected = '';
	}

	if ($can_change_subscriptions == 0) {
		$selected .= ' disabled ';
	}

	$status_select .= "<option {$selected} value='1'>" . JText::_('COM_RSEVENTSPRO_RULE_STATUS_COMPLETE') . "</option>";
	if ($item->state == 2) {
		$selected = 'selected="selected"';
	} else {
		$selected = '';
	}
	if ($can_change_subscriptions == 0) {
		$selected .= ' disabled ';
	}
	$status_select .= "<option {$selected} value='2'>" . JText::_('COM_RSEVENTSPRO_RULE_STATUS_DENIED') . "</option>";
	if ($item->state == 3) {
		$selected = 'selected="selected"';
	} else {
		$selected = '';
	}
	if ($can_change_subscriptions == 0) {
		$selected .= ' disabled ';
	}
	$status_select .= "<option {$selected} value='3'>" . JText::_('COM_RSEVENTSPRO_RULE_STATUS_REFUNDED') . "</option>";

	$status_select .= "</select> ";
	$purchasedtickets .= '<div class="modal" tabindex="-1" id="ticketModal_' . $item->id . '">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">' . JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CONFIRM_HEADING_LABEL') . '</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body"  > 
			
			<table class="table">
			
			<tr>
			<td  align="left"  >
			 <b>' . JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_NAME') . '</b> 
			</td>
			<td align="left">
			 ' . $item->name . ' </td>
			 </tr>
			 <tr>
			 <td  align="left" >
			 <b>' . JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_EVENT') . '</b>  
			</td>
			
			<td align="left">
			 ' .  $item->event . ' </td>
			</tr>
			 <tr>
			 <td  align="left"  >
			 <b>' . JText::_('COM_RSEVENTSPRO_SUBSCRIBER_DATE') . '</b>  
			</td>
			
			<td align="left">
			 ' .  rseventsproHelper::showdate($item->date, null, true)  . ' </td>
			</tr>
			  <tr>
			 <td  align="left" >
			 <b>' . JText::_('COM_RSEVENTSPRO_SUBSCRIBERS_HEAD_STATUS') . '</b>  
			</td>
			
			<td align="left">' . $status_select . ' </td>
			</tr>
			
			<table>';

	$purchasedtickets .= '<table width="100%" class=" mb-3 ">
		<tr>
			<td align="right" > <i class="preloader-add-ticket d-none fa fa-spinner fa-spin"></i> 
			<button onclick="get_tickets(\'' . $item->ide . '\',\'' . $item->id . '\',\'' . $item->SubmissionId . '\')" class="btn btn-sm btn-primary btn-add-ticket" type="button" > <i class="fa-solid fa-plus"></i> ' . JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_ADD_TICKETS_LABEL') . '</button>
			<button onclick="cancel_tickets(\'' . $item->id . '\')" class="btn btn-sm btn-warning d-none btn-cancel-ticket" type="button" > <i class="fa-solid fa-times"></i> ' . JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_CANCEL_TICKETS_LABEL') . '</button>
			</td>
			</tr>
			</table>
			<div class="new-ticket-response mb-3" ></div>
			';
	return $purchasedtickets ;
} ?>