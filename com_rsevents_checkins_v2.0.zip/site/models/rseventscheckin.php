<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JLoader::register('RseventscheckinHelperRoute', JPATH_ROOT . '/components/com_rseventscheckin/helpers/route.php');


/**
 * RseventsCheckin Model
 *
 * @since  0.0.1
 */
class RseventsCheckinModelRseventsCheckin extends JModelList
{
	/**
	 * @var object item
	 */
	protected $item;
	public $_data = array();
	public $submission_ids = array();
	/**
	 * Method to auto-populate the model state.
	 *
	 * This method should only be called once per instantiation and is designed
	 * to be called on the first call to the getState() method unless the model
	 * configuration flag to ignore the request is set.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @return	void
	 * @since	2.5
	 */
	public function __construct($config = array())
	{
		 
		parent::__construct($config);
	}
	/**
	 * Method to get a table object, load it if necessary.
	 *
	 * @param   string  $type    The table name. Optional.
	 * @param   string  $prefix  The class prefix. Optional.
	 * @param   array   $config  Configuration array for model. Optional.
	 *
	 * @return  JTable  A JTable object
	 *
	 * @since   1.6
	 */
 
	 public function checkFormColumns($formId,$fields_array)
	 {
		$db = JFactory::getDbo();
		$results=[];
		if(!empty($fields_array))
		{
			$fields_array_string=implode("','",$fields_array);
			$fields_array_string="'$fields_array_string'";
			$query = $db->getQuery(true)
				 ->select($db->qn('ColumnName'))
				 ->from($db->qn('#__rsform_submission_columns'))
				 ->where($db->qn('FormId') . ' = ' . $db->q($formId)  ) 
				 ->where($db->qn('ColumnName') . ' in (' . $fields_array_string .')' );
				 $db->setQuery($query);
				$results = $db->loadObjectList();	 
		}
 
		return $results;
		 
	 }
	 
	public function getEvents()
	{
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$active	= rseventsproHelper::getConfig('active_events');
		$tz		= JFactory::getConfig()->get('offset');

		$query->clear()
			->select($db->qn('id', 'value'))
			->select($db->qn('name', 'text'))
			->select($db->qn('start'))
			->select($db->qn('form'))
			->from($db->qn('#__rseventspro_events'))
			->where($db->qn('registration') . ' = 1  ')
			->order($db->qn('start') . ' ASC');

		$today = JFactory::getDate();
		$today->setTime(0, 0, 0);
		$today = $today->toSql();

		$today = JFactory::getDate($today, $tz);
		$today->setTimezone(new DateTimezone('UTC'));
		$today = $today->toSql();
		
		//$query->where(  $db->qn('published') .' = '. $db->q(1) .' AND ' .$db->qn('archived') .' = ' . $db->q(0) );
		$query->where(  $db->qn('published') .' = '. $db->q(1)     );
		$cuser=JFactory::getUser();
		$user_id=$cuser->id;
		 
		 
		if(!$cuser->authorise('core.admin')){
			 $query->where(  $db->qn('owner') . ' = ' . $db->q($user_id));
		}

		if ($active) {
	     	//$query->where('((' . $db->qn('end') . ' >= ' . $db->q(JFactory::getDate()->toSql()) . ' AND ' . $db->qn('end') . ' != ' . $db->q($db->getNullDate()) . ') OR (' . $db->qn('end') . ' = ' . $db->q($db->getNullDate()) . ' AND DATE(' . $db->qn('start') . ') >= ' . $db->q($today) . '))');
			  $query->where('((' .  $db->qn('end') . ' != ' . $db->q($db->getNullDate()) . ') OR (' . $db->qn('end') . ' = ' . $db->q($db->getNullDate()) . ' AND DATE(' . $db->qn('start') . ') >= ' . $db->q($today) . '))');
		}

		 
		$db->setQuery($query);
		return $events = $db->loadObjectList();
		 
	}
	public function getTotalSubscribers($event_id)
	{
	 $db = JFactory::getDbo();
	 $query	= $db->getQuery(true);
	 $query->clear()
			 ->select('u.*')
			 ->select($db->qn('e.form')) 
			 ->from($db->qn('#__rseventspro_users','u'))
			 ->join('left',$db->qn('#__rseventspro_events','e').' ON '.$db->qn('e.id').' = '.$db->qn('u.ide'));
		 
		 /* if (array_key_exists('tickets', self::$filters) || array_key_exists('ticket', self::$filters)) {
			 $query->join('left',$db->qn('#__rseventspro_user_tickets','ut').' ON '.$db->qn('ut.ids').' = '.$db->qn('u.id'));
			 
		 } */
		 if(!empty( $event_id)){
			$query->where($db->qn('u.ide').' = '. (int) $event_id);
		}
		 
		 $db->setQuery($query);
		 $count = $db->execute();
		 return $count = $db->getNumRows();
	}

	public function getTotalSubscribersBYState($event_id,$state=0)
	{
	 $db = JFactory::getDbo();
	 $query	= $db->getQuery(true);
	 $query->clear()
			 ->select('u.*')
			 ->select($db->qn('e.form')) 
			 ->from($db->qn('#__rseventspro_users','u'))
			 ->join('left',$db->qn('#__rseventspro_events','e').' ON '.$db->qn('e.id').' = '.$db->qn('u.ide'));
		
		$where=[];
			if(!empty( $event_id)){
					$where[]=$db->qn('u.ide').' = '. (int) $event_id ;
			}
			 
			$where[]=$db->qn('u.state').' = '. (int) $state;
			 
		 $query->where( implode(' AND ',$where)  );
		 $db->setQuery($query);
		 $count = $db->execute();
		 return $count = $db->getNumRows();
	}
	public function getTotalcheckedSubscribers($event_id)
	{
	 $db = JFactory::getDbo();
	 $query	= $db->getQuery(true);
	 $query->clear()
			 ->select('SUM('.$db->qn('ut.quantity').') as total' )
			 ->from($db->qn('#__rseventspro_users','u'))
			 ->join('INNER',$db->qn('#__rseventspro_events','e').' ON '.$db->qn('e.id').' = '.$db->qn('u.ide'));
	
		$query->join('INNER',$db->qn('#__rseventspro_user_tickets','ut').' ON '.$db->qn('ut.ids').' = '.$db->qn('u.id'));
			
		$where=[];
			if(!empty( $event_id)){
					$where[]=$db->qn('u.ide').' = '. (int) $event_id ;
			}
			 
			 
		 $query->where( implode(' AND ',$where)  );
		 $db->setQuery($query);
		 $total_tickets = $db->loadObject()->total;
		 $query	= $db->getQuery(true); 
		 $sql=" SELECT     (sum(`uts`.quantity) -(SELECT  COUNT( ids)  from `#__rseventspro_confirmed`  
		 WHERE     ids=  `uts`.ids    )) AS `total`
			  FROM `#__rseventspro_users` AS `u` 
		 LEFT JOIN `#__rseventspro_events` AS `e` ON `e`.`id` = `u`.`ide`
		 LEFT JOIN `#__rseventspro_user_tickets` AS `uts` ON `u`.`id` = `uts`.`ids` 
		 WHERE     `u`.`ide` = {$event_id} AND `e`.`id` <> 0  AND `u`.`state`=1  GROUP BY `uts`.ids  ";
		 $db->setQuery($sql);
		 $results = $db->loadObjectList();
		 $checked=0;
		 $unchecked=0;
		 $unchecked_ticket=0;	
		 
		 foreach($results as $result) {
			//if differece is not zero means somes tickets are unconfirmed so increase unchecked counter by one
			if((int)$result->total==0){
				$checked+=1;
			}else{
				$unchecked+=1;
			 
				$unchecked_ticket+=(int)$result->total;
			}
			
		 }
		return (object)['checked'=>$checked,'unchecked'=>$unchecked,'unchecked_tickets'=>$unchecked_ticket ];
	}
	public function isOrderingPossible($field)
	{
		$db = $this->getDbo();

		   $query = $db->getQuery(true)
			->select($db->qn('SubmissionValueId'))
			->from($db->qn('#__rsform_submission_values'))
			->where($db->qn('FieldName') . ' = ' . $db->q($field))
			->where($db->qn('FormId') . ' = ' . $db->q($this->getFormId()));

		$db->setQuery($query);
		return $db->loadResult();
	}
	protected function getListQuery()
	{
		$sortColumn 	= $this->getSortColumn();
		$sortOrder 		= $this->getSortOrder();
		$formId 		= $this->getFormId();
		$filter 		= $this->getFilter();
		$languageFilter	= $this->getLang();
		$isStaticHeader = in_array($sortColumn, array_keys($this->getStaticHeaders()));
		 
		$join			= false;
		$db             = $this->getDbo();

		$query = $db->getQuery(true)
			->select('s.*')
			->from($db->qn('#__rsform_submissions', 's'))
			->where($db->qn('s.FormId') . ' = ' . $db->q($formId));

		// Only for export - export selected rows
		if (!empty($this->submission_ids)) {
			$query->where($db->qn('s.SubmissionId') . ' IN (' . implode(',', $db->q($this->submission_ids)) . ')');
		}
 
		// Check if there's a filter (search) set
		/* if (!$this->export) {
			if ($filter !== null && $filter !== '' && strlen($filter)) {
				$or 			= array();
				$join 			= true;
				$escapedFilter  = $db->q('%' . $db->escape($filter) . '%', false);

				if (!preg_match('#([^0-9\-: ])#', $filter)) {
					$or[] = $db->qn('s.DateSubmitted') . ' LIKE ' . $escapedFilter;
				}
				$or[] = $db->qn('s.Username') . ' LIKE ' . $escapedFilter;
				$or[] = $db->qn('s.UserIp') . ' LIKE ' . $escapedFilter;

				if ($isStaticHeader) {
					$or[] = $db->qn('sv.FieldValue') . ' LIKE ' . $escapedFilter;
				} else {
					$subquery = $db->getQuery(true)
						->select($db->qn('SubmissionId'))
						->from($db->qn('#__rsform_submission_values'))
						->where($db->qn('FormId') . ' = ' . $db->q($formId))
						->where($db->qn('FieldValue') . ' LIKE ' . $escapedFilter);

					$or[] = $db->qn('s.SubmissionId') . ' IN (' . $subquery . ')';
				}

				$query->where('(' . implode(' OR ', $or) . ')');
			}

			if ($languageFilter) {
				$query->where($db->qn('s.Lang') . ' = ' . $db->q($languageFilter));
			}

			if ($from = $this->getDateFrom()) {
				$query->where($db->qn('s.DateSubmitted') . ' >= ' . $db->q(JFactory::getDate($from)->toSql()));
			}

			if ($to = $this->getDateTo()) {
				$query->where($db->qn('s.DateSubmitted') . ' <= ' . $db->q(JFactory::getDate($to)->toSql()));
			}
		} */

		// Order by static headers
		if ($isStaticHeader) {
			$query->order($db->qn('s.' . $sortColumn) . ' ' . $db->escape($sortOrder));
		} else {
			$join = true;
 
			

			$query->order($db->qn('sv.FieldValue') . ' ' . $db->escape($sortOrder));
		}
		 
		if ($join) {

			$join_field='';
			if ($this->isOrderingPossible($sortColumn)) {
				$join_field =' And ' . $db->qn('sv.FieldName') . ' = ' . $db->q($sortColumn) ;
			}
			$query->join('left', $db->qn('#__rsform_submission_values', 'sv') . ' ON (' . $db->qn('s.SubmissionId') . ' = ' . $db->qn('sv.SubmissionId') . $join_field . ')')
				->group(array($db->qn('s.SubmissionId')));
		}
      
		 
		return $query;
	}

	
	public static function getSubscriptionsQuery() {
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$from	= array_key_exists('from', self::$filters) ? self::$filters['from'] : '';
		$to		= array_key_exists('to', self::$filters) ? self::$filters['to'] : '';
		
		$barcode_prefix = rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-');
		
		$query->clear()
			->select('u.*')
			->select($db->qn('e.name','event'))->select($db->qn('e.start'))
			->select($db->qn('e.end'))->select($db->qn('e.allday'))
			->from($db->qn('#__rseventspro_users','u'))
			->join('left',$db->qn('#__rseventspro_events','e').' ON '.$db->qn('e.id').' = '.$db->qn('u.ide'));
		
		if (array_key_exists('tickets', self::$filters) || array_key_exists('ticket', self::$filters)) {
			$query->join('left',$db->qn('#__rseventspro_user_tickets','ut').' ON '.$db->qn('ut.ids').' = '.$db->qn('u.id'));
		}
		
		if (array_key_exists('tickets', self::$filters)) {
			$query->select($db->qn('ut.quantity'));
			$query->select($db->qn('t.id', 'tid'))->select($db->qn('t.name', 'ticketname'))->select($db->qn('t.price'));
			$query->join('left',$db->qn('#__rseventspro_tickets','t').' ON '.$db->qn('t.id').' = '.$db->qn('ut.idt'));
			$query->where($db->qn('u.state').' = 1');
			
			if (array_key_exists('ide', self::$filters)) {
				$subquery = $db->getQuery(true);
				
				$subquery->clear()
					->select($db->qn('id'))
					->from($db->qn('#__rseventspro_tickets'))
					->where($db->qn('ide').' = '.(int) self::$filters['ide']);
				
				$query->where($db->qn('t.id').' IN ('.$subquery.')');
			}
		}
		
		if (array_key_exists('ide', self::$filters)) {
			$query->where($db->qn('u.ide').' = '. (int) self::$filters['ide']);
		}
		
		if (array_key_exists('search', self::$filters)) {
			$where	= array();
			$search = $db->q('%'.$db->escape(self::$filters['search'], true).'%');
			
			if (array_key_exists('tickets', self::$filters) && strpos(self::$filters['search'], $barcode_prefix) !== false) {
				$limit = 10;
				
				if (array_key_exists('ide', self::$filters)) {
					$subquery = $db->getQuery(true);
					
					$subquery->clear()
						->select('MAX('.$db->qn('ut.quantity').')')
						->from($db->qn('#__rseventspro_users','u'))
						->join('left',$db->qn('#__rseventspro_user_tickets','ut').' ON '.$db->qn('ut.ids').' = '.$db->qn('u.id'))
						->where($db->qn('u.ide').' = '. (int) self::$filters['ide'])
						->where($db->qn('ut.idt').' <> 0');
					
					JFactory::getApplication()->triggerEvent('onrsepro_subscriptionsQuery', array(array('query' => &$subquery, 'rule' => 'u.ide')));
					
					$db->setQuery($subquery);
					$limit = (int) $db->loadResult();
				}
				
				if ($limit) {
					$search = str_replace($barcode_prefix, '', $search);
					
					for ($i=1;$i<=$limit;$i++) {
						$where[] = 'CONCAT_WS("-",'.$db->qn('u.id').',CONCAT(SUBSTR(MD5(CONCAT('.$db->qn('u.id').', '.$db->qn('t.id').', '.$i.')), 1, 4), SUBSTR(MD5(CONCAT('.$db->qn('u.id').', '.$db->qn('t.id').', '.$i.')), -4))) LIKE '.$search;
					}
				}
			}
			
			$where = !empty($where) ? ' OR '.implode(' OR ', $where) : '';
			$query->where('('.$db->qn('e.name').' LIKE '.$search.' OR '.$db->qn('u.name').' LIKE '.$search.' OR '.$db->qn('u.email').' LIKE '.$search.$where.')');
		}
		
		if (array_key_exists('ticket', self::$filters)) {
			$query->where($db->qn('ut.idt').' = '.(int) self::$filters['ticket']);
		}
		
		if (array_key_exists('state', self::$filters)) {
			$query->where($db->qn('u.state').' = '.(int) self::$filters['state']);
		}
		
		if (array_key_exists('language', self::$filters)) {
			$query->where($db->qn('u.lang').' = '.$db->q(self::$filters['language']));
		}
		
		if (array_key_exists('payment', self::$filters)) {
			if (self::$filters['payment'] == 'none') self::$filters['payment'] = '';
			$query->where($db->qn('u.gateway').' = '.$db->q(self::$filters['payment']));
		}
		
		if (array_key_exists('cart', self::$filters) && !self::$filters['cart']) {
			$query->where($db->qn('e.id').' <> 0');
		}
		
		if (empty($from) && !empty($to)) {
			$query->where($db->qn('u.date').' <= '.$db->q($to));
		} elseif (!empty($from) && empty($to)) {
			$query->where($db->qn('u.date').' >= '.$db->q($from));
		} elseif (!empty($from) && !empty($to)) {
			$query->where($db->qn('u.date').' >= '.$db->q($from));
			$query->where($db->qn('u.date').' <= '.$db->q($to));
		}
		
		$orderby 	= array_key_exists('list.order', self::$filters) ? self::$filters['list.order'] : 'u.date';
		$orderdir	= array_key_exists('list.dir', self::$filters) ? self::$filters['list.dir'] : 'DESC';
		
		$query->order($db->qn($orderby).' '.$orderdir);
	 
		JFactory::getApplication()->triggerEvent('onrsepro_subscriptionsQuery', array(array('query' => &$query, 'rule' => 'u.ide')));
		
		return $query;
	}


	protected function populateState($ordering = null, $direction = null)    
	{         
		 
	parent::populateState($ordering, $direction);
	} 
	public function getSortColumn()
	{
		$order = JFactory::getApplication()->input->get('list','','string');
		$value='';
		if(isset($order['fullordering'] )){
			$orders= explode(' ' ,$order['fullordering']  );
			$value=isset($orders[0]) ?$orders[0]:'';
		} 
		
		 
		$this->setState('filter.order', $value);
		return $this->getState('list.ordering', $value);
	} 

	public function getSortOrder()
	{
		$order = JFactory::getApplication()->input->get('list','','string');
		$value='';
		if(isset($order['fullordering'] )){
		$orders= explode(' ' ,$order['fullordering']  );
		$value=isset($orders[1]) ?$orders[1]:'';
		}
		$this->setState('list.direction',$value); 
		return $this->getState('list.direction',$value);
	}
	public function getHeaders($header_columns)
	{

		$db     = JFactory::getDbo();
		$formId = $this->getFormId();

		$query = $db->getQuery(true)
			->select($db->qn('p.PropertyValue'))
			->from($db->qn('#__rsform_components', 'c'))
			->join('left', $db->qn('#__rsform_properties', 'p') . ' ON (' . $db->qn('c.ComponentId') . '=' . $db->qn('p.ComponentId') . ' AND ' . $db->qn('p.PropertyName') . ' = ' . $db->q('NAME') . ')')
			->join('left', $db->qn('#__rsform_component_types', 'ct') . ' ON (' . $db->qn('c.ComponentTypeId') . '=' . $db->qn('ct.ComponentTypeId') . ')')
			->where($db->qn('c.FormId') . ' = ' . $db->q($formId))
			->where($db->qn('c.Published') . ' = ' . $db->q(1));
		if (!empty($header_columns)) {
			$query->where($db->qn('p.PropertyValue') . '  IN (' . implode(',', $db->q($header_columns)) . ')');
		}

		$query->order($db->qn('c.Order'));

		$headers = $db->setQuery($query)->loadColumn();

		JFactory::getApplication()->triggerEvent('onRsformBackendGetSubmissionHeaders', array(&$headers, $formId));

		// Get labels
		$results = array();
		if ($headers) {
			foreach ($headers as $header) {
				$value = $header;



				$results[$value] = new RSFormProSubmissionHeader($value, $header, 0, $formId);
			}
		}

		return $results;
	}
	public function updateSubmissionState($id, $state)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->clear()
			->update($db->qn('#__rseventspro_users'))
			->set($db->qn('state') . ' = ' . (int) $state)
			->where($db->qn('id') . ' = ' . (int) $id);

		$db->setQuery($query);
		$db->execute();
	}
	public function addNote($form_id,$submissionid,$fieldname, $fieldvalue)
	{
		
		$db = JFactory::getDbo();
		$columns=['FormId','SubmissionId','FieldName','FieldValue'];
		$values = array($db->quote($form_id),$db->quote($submissionid),$db->quote($fieldname),$db->quote($fieldvalue)); 
		
		$query = $db->getQuery(true);
		$query->clear()
			->insert($db->quoteName('#__rsform_submission_values'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));
 
		$db->setQuery($query);
		$db->execute();
		return $new_row_id = $db->insertid();
	}



	public function updateNote($id, $value)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->clear()
			->update($db->qn('#__rsform_submission_values'))
			->set($db->qn('FieldValue') . ' = '  . $db->q($value))
			->where($db->qn('SubmissionValueId') . ' = ' . (int) $id);

		$db->setQuery($query);
		$db->execute();
	}

	public function getTicketsByEventID($event_id)
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->clear()
			->select($db->qn('t').'.*')
			->from($db->qn('#__rseventspro_tickets','t'))
			->where($db->qn('t.ide').' = '. (int) $event_id);

		$db->setQuery($query);
		return $tickets = $db->loadObjectList();		
	}

	public function addNewTicket($idt,$qty,$ids,$sid,$confirm)  
	{
		
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		//////////////////////////////////////////////////////////////////////

			$query->clear()
				->select('*')
				->from($db->qn('#__rsform_submissions'))
				->where($db->qn('SubmissionId') . ' = ' . (int) $sid);
			$db->setQuery($query);
			
			$submission_info= $db->loadObject();
			$form_id=$submission_info->FormId;
		
		//////////////////////////////////////////////////////////////////////

			$columns = array('ids', 'idt', 'quantity' );		
			$values = array($ids, $idt, $qty);
			$query->clear()
				->insert($db->quoteName('#__rseventspro_user_tickets'))
				->columns($db->quoteName($columns))
				->values(implode(',', $values));
			$db->setQuery($query);
			 
			$db->execute();	
		 
		
			if($confirm=='true'){
				for($loop=1;$loop<=$qty;$loop++){
					$code	= md5($ids . $idt . $loop);
					$code	= substr($code, 0, 4) . substr($code, -4);
					$code	= rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-') . $ids . '-' . $code;
					$code   = in_array(rseventsproHelper::getBarcodeOptions('barcode', 'C39'), array('C39', 'C93')) ? strtoupper($code) : $code;

					$columns = array('ids', 'code'  );		
					$values = array($ids, $db->quote($code) );
					$query->clear()
						->insert($db->quoteName('#__rseventspro_confirmed'))
						->columns($db->quoteName($columns))
						->values(implode(',', $values));
					$db->setQuery($query);
					$db->execute();
				}
			
			}
		
		////////////////////////////////////////////////////////////////////// 

			$query->clear()
			->select($db->qn('ut.quantity'))->select($db->qn('t').'.*')
			->from($db->qn('#__rseventspro_user_tickets','ut'))
			->join('left', $db->qn('#__rseventspro_tickets','t').' ON '.$db->qn('t.id').' = '.$db->qn('ut.idt'))
			->where($db->qn('ut.ids').' = '. (int) $ids);
			$db->setQuery($query);
			$tickets = $db->loadObjectList();
			$total_ticket_price=0;
			
			if ($tickets) {
				foreach ($tickets as $ticket) {
					$ticket_name=$ticket->name;
					$ticket_price=$ticket->price;
					$ticket_quantity=$ticket->quantity;
					$rseprotickets_values[]=$ticket_quantity.' x '.$ticket_name .' ('.rseventsproHelper::currency($ticket_price).')';
					$total_ticket_price+=$ticket_quantity*$ticket_price;
				}
			}  
			$rseprotickets_values[]= 'Total: '.rseventsproHelper::currency($total_ticket_price) ;

		//////////////////////////////////////////////////////////////////////

			$query->clear()
				->select('*')
				->from($db->qn('#__rsform_submission_values'))
				->where($db->qn('SubmissionId') . ' = ' . (int) $sid)
				->where($db->qn('FormId') . ' = ' . (int) $form_id)
				->where($db->qn('FieldName') . " = 'RSEProTickets' ") ;
				
			$db->setQuery($query);
			$submission_values= $db->loadObject();
			$submission_value_id=$submission_values->SubmissionValueId;
			$field_value=$submission_values->FieldValue; 
			
			
		//////////////////////////////////////////////////////////////////////

			$RSEProTickets_value=implode(' , ',$rseprotickets_values);
			$query->clear()
			->update($db->qn('#__rsform_submission_values'))
			->set($db->qn('FieldValue') . ' = ' . $db->q($RSEProTickets_value ))
			->where($db->qn('SubmissionValueId') . ' = ' . $db->q($submission_value_id)) ;
			$db->setQuery($query);	
			$db->execute();

	}
	public function deleteTicket($submission_id,$ticket_id,$item_id,$code, $confirm_code_id)
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);

		$user_balance_ticket_quantity =0;
		$rseprotickets_values=[];
		 
		//////////////////////////////////////////////////////////////////////
		 
		$query->clear()
			->select($db->qn('ut.quantity'))->select($db->qn('t').'.*')
			->from($db->qn('#__rseventspro_user_tickets','ut'))
			->join('left', $db->qn('#__rseventspro_tickets','t').' ON '.$db->qn('t.id').' = '.$db->qn('ut.idt'))
			->where($db->qn('ut.ids').' = '. (int) $item_id);

		$db->setQuery($query);
		$tickets = $db->loadObjectList();
		$total_ticket_price=0;
		
		 if ($tickets) {
			foreach ($tickets as $ticket) 
			{
				$ticket_name=$ticket->name;
				$ticket_price=$ticket->price;
				$ticket_quantity=$ticket->quantity;
				if($ticket->id==$ticket_id){
					$user_balance_ticket_quantity = $ticket_quantity-1;
					if($user_balance_ticket_quantity>0)
					{
						$rseprotickets_values[]=$user_balance_ticket_quantity.' x '.$ticket_name .' ('.rseventsproHelper::currency($ticket_price).')';
						$total_ticket_price+=$user_balance_ticket_quantity*$ticket_price;
					}
				}else{
					$rseprotickets_values[]=$ticket_quantity.' x '.$ticket_name .' ('.rseventsproHelper::currency($ticket_price).')';
					$total_ticket_price+=$ticket_quantity*$ticket_price;
				}
				 
			}
		}  
		$rseprotickets_values[]= 'Total: '.rseventsproHelper::currency($total_ticket_price) ;


		//////////////////////////////////////////////////////////////////////
		$query->clear()
			->select('*')
			->from($db->qn('#__rsform_submissions'))
			->where($db->qn('SubmissionId') . ' = ' . (int) $submission_id);
		$db->setQuery($query);
		 
		$submission_info= $db->loadObject();
		 
		$form_id=$submission_info->FormId;
		
		//////////////////////////////////////////////////////////////////////

		$query->clear()
			->select('*')
			->from($db->qn('#__rsform_submission_values'))
			->where($db->qn('SubmissionId') . ' = ' . (int) $submission_id)
			->where($db->qn('FormId') . ' = ' . (int) $form_id)
			->where($db->qn('FieldName') . " = 'RSEProTickets' ") ;
			
		$db->setQuery($query);
		$submission_values= $db->loadObject();
		$submission_value_id=$submission_values->SubmissionValueId;
		$field_value=$submission_values->FieldValue; 
		
		
		//////////////////////////////////////////////////////////////////////

		$RSEProTickets_value=implode(' , ',$rseprotickets_values);

		if($user_balance_ticket_quantity==0){
			$query->clear()			
			->delete($db->qn('#__rseventspro_user_tickets'))
			->where($db->qn('idt') . ' = ' . $db->q($ticket_id)) 
			->where($db->qn('ids') . ' = ' . (int) $item_id);
			$db->setQuery($query);	
			$db->execute();

			//////////////////////////////////////////////////////////////////////
			$query->clear()
			->update($db->qn('#__rsform_submission_values'))
			->set($db->qn('FieldValue') . ' = ' . $db->q($RSEProTickets_value ))
			->where($db->qn('SubmissionValueId') . ' = ' . $db->q($submission_value_id)) ;
			$db->setQuery($query);	
			$db->execute();
			

		}else{
			$query->clear()
				->update($db->qn('#__rseventspro_user_tickets'))
				->set($db->qn('quantity') . ' = ' . $db->q($user_balance_ticket_quantity ))
				->where($db->qn('idt') . ' = ' . $db->q($ticket_id)) 
				->where($db->qn('ids') . ' = ' . (int) $item_id);
				$db->setQuery($query);	
				$db->execute();
				
				 

			//////////////////////////////////////////////////////////////////////
			$query->clear()
			->update($db->qn('#__rsform_submission_values'))
			->set($db->qn('FieldValue') . ' = ' . $db->q($RSEProTickets_value ))
			->where($db->qn('SubmissionValueId') . ' = ' . $db->q($submission_value_id)) ;
			$db->setQuery($query);	
			$db->execute();

		}
		//////////////////////////////////////////////////////////////////////

		if($confirm_code_id>0){
			$query->clear()
				->delete($db->qn('#__rseventspro_confirmed'))
				->where($db->qn('code') . ' = ' . $db->q($code ))
				->where($db->qn('ids') . ' = ' . (int) $item_id);
				$db->setQuery($query);	
				$db->execute();
		}
		 
	}

	

	public function getUnescapedFields()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select($db->qn('p.PropertyValue'))
			->from($db->qn('#__rsform_components', 'c'))
			->join('left', $db->qn('#__rsform_properties', 'p') . ' ON (' . $db->qn('c.ComponentId') . '=' . $db->qn('p.ComponentId') . ')')
			->where($db->qn('c.FormId') . ' = ' . $db->q($this->getFormId()))
			->where($db->qn('c.ComponentTypeId') . ' = ' . $db->q(RSFORM_FIELD_FILEUPLOAD))
			->where($db->qn('p.PropertyName') . ' = ' . $db->q('NAME'));
		$fields = $db->setQuery($query)->loadColumn();


		return $fields;
	}
	public function getPermission()
	{
		$user = JFactory::getUser();
		$groups = $user->get('groups');
		$gp = [];
		foreach ($groups as $group) {
			$gp[] = '%"' . $group . '"%';
		}

		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
			->select('*')
			->from($db->qn('#__rseventspro_groups', 'g'));
		$query->where('1  =  1');
		$group_wheres = [];
		foreach ($groups as $group) {
			$group_wheres[] = $db->qn('g.jgroups') . '  LIKE  ' .  $db->quote('%"' . $group . '"%');
		}
		$query->extendWhere('AND', $group_wheres, 'OR');
		$query->extendWhere('OR', [$db->qn('g.jusers') . '  LIKE  ' .  $db->quote('%"' . $user->id . '"%')], '');

		$db->setQuery($query);
		//echo $query;
		return $data = $db->loadObjectList();
	}
	public function getSubmissions($formId)
	{

		$this->setFormId($formId);
		if (empty($this->_data)) {

			$app	= JFactory::getApplication();
			$db     = $this->getDbo();
			$form   = $this->getFormProperties();

			$multipleSeparator = $form->MultipleSeparator;
			if ($this->multipleSeparator !== null) {
				$multipleSeparator = $this->multipleSeparator;
			}
			$multipleSeparator = str_replace(array('\n', '\r', '\t'), array("\n", "\r", "\t"), $multipleSeparator);

			if (empty($form)) {
				return $this->_data;
			}

			$uploadFields 	= array();
			$multipleFields = array();
			$textareaFields = array();
			$fieldTypes = $this->getSpecialFields();
			if (isset($fieldTypes['uploadFields'])) {
				$uploadFields = $fieldTypes['uploadFields'];
			}
			if (isset($fieldTypes['multipleFields'])) {
				$multipleFields = $fieldTypes['multipleFields'];
			}
			if (isset($fieldTypes['textareaFields'])) {
				$textareaFields = $fieldTypes['textareaFields'];
			}

			$db->setQuery("SET SQL_BIG_SELECTS=1")->execute();

			$results = $this->_getList($this->getListQuery());

			foreach ($results as $result) {
				$this->_data[$result->SubmissionId] = array(
					'SubmissionId'     => $result->SubmissionId,
					'FormId'           => $result->FormId,
					'DateSubmitted'    => RSFormProHelper::getDate($result->DateSubmitted),
					'UserIp'           => $result->UserIp,
					'Username'         => $result->Username,
					'UserId'           => $result->UserId,
					'Lang'             => $result->Lang,
					'confirmed'        => $result->confirmed ? JText::_('RSFP_YES') : JText::_('RSFP_NO'),
					'SubmissionValues' => array(),
				);
			}

			$submissionIds = array_keys($this->_data);

			if (!empty($submissionIds)) {
				$must_escape = $app->input->get('view') == 'submissions' && $app->input->get('layout') == 'default';

				$query = $db->getQuery(true)
					->select('*')
					->from($db->qn('#__rsform_submission_values'))
					->where($db->qn('SubmissionId') . ' IN (' . implode(',', $db->q($submissionIds)) . ')');

				$results = $db->setQuery($query)->loadObjectList();
				foreach ($results as $result) {
					// Check if this is an upload field
					if (in_array($result->FieldName, $uploadFields) && !empty($result->FieldValue) && !$this->export) {
						$files = RSFormProHelper::explode($result->FieldValue);

						$values = array();
						foreach ($files as $file) {
							$values[] = '<a href="index.php?option=com_rsform&amp;task=submissions.viewfile&amp;id=' . $result->SubmissionValueId . '&amp;file=' . md5($file) . '">' . RSFormProHelper::htmlEscape(basename($file)) . '</a>';
						}

						$result->FieldValue = implode('<br />', $values);
					} else {
						// Check if this is a multiple field
						if (in_array($result->FieldName, $multipleFields)) {
							$result->FieldValue = str_replace("\n", $multipleSeparator, $result->FieldValue);
						}
						// Transform new lines
						elseif ($form->TextareaNewLines && in_array($result->FieldName, $textareaFields)) {
							if ($must_escape) {
								$result->FieldValue = RSFormProHelper::htmlEscape($result->FieldValue);
							} elseif ($this->exportType === 'csv' && !$this->stripLines) {
								$result->FieldValue = nl2br($result->FieldValue);
							}
						} elseif ($must_escape) {
							$result->FieldValue = RSFormProHelper::htmlEscape($result->FieldValue);
						}
					}

					$this->_data[$result->SubmissionId]['SubmissionValues'][$result->FieldName] = array(
						'Value' => $result->FieldValue,
						'Id'    => $result->SubmissionValueId
					);
				}
			}
			unset($results);
		}

		return $this->_data;
	}
	public function getFormProperties()
	{
		return RSFormProHelper::getForm($this->getFormId());
	}

	public function getFormId()
	{

		$formId = $this->firstFormId;



		return $formId;
	}
	public function setFormId($formId)
	{

		$this->firstFormId = $formId;
	}

	public function getDateFrom()
	{
		return $this->getState('filter.dateFrom');
	}

	public function getDateTo()
	{
		return $this->getState('filter.dateTo');
	}

	public function getLang()
	{
		return $this->getState('filter.language');
	}

	public function getFilter()
	{
		return $this->getState('filter.search');
	}

	public function getSpecialFields()
	{
		return RSFormProHelper::getDirectoryFormProperties($this->getFormId(), true);
	}

	public function getStaticHeaders()
	{
		$headers = array('SubmissionId', 'DateSubmitted', 'UserIp', 'Username', 'UserId', 'Lang');

		if ($this->addConfirmedHeader()) {
			$headers[] = 'confirmed';
		}

		$results = array();

		foreach ($headers as $header) {
			$results[$header] = new RSFormProSubmissionHeader($header, JText::_('RSFP_' . $header), 1, $this->getFormId());
		}

		return $results;
	}

	public function addConfirmedHeader()
	{
		if ($form = $this->getFormProperties()) {
			return (bool) $form->ConfirmSubmission;
		}

		return false;
	}

	public function confirm($id, $code,$confirm) {
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		
		$query->select($db->qn('id'))
			->from('#__rseventspro_confirmed')
			->where($db->qn('ids').' = '.$db->q($id))
			->where($db->qn('code').' = '.$db->q($code));
		$db->setQuery($query);
		if (!$db->loadResult() && $confirm ) {
			$query->clear()
				->insert('#__rseventspro_confirmed')
				->set($db->qn('ids').' = '.$db->q($id))
				->set($db->qn('code').' = '.$db->q($code));
			$db->setQuery($query);
			if ($db->execute()) {
				return json_encode(array('status' => true, 'message' => JText::_('JYES')));
			}
		}

		if ($db->loadResult() && !$confirm ) {
			$conditions = array(
				$db->qn('ids') .  ' = '.$db->q($id) ,
				$db->qn('code') .  ' = '.$db->q($code) ,
			);
			$query->clear()
				->delete('#__rseventspro_confirmed');
				$query->where($conditions);
			$db->setQuery($query);
			if ($db->execute()) {
				return json_encode(array('status' => true, 'message' => JText::_('JYES')));
			}
		}
		return json_encode(array('status' => false));
	}

}

class RSFormProSubmissionHeader
{
	/* @var string Holds the actual value of the header */
	public $value;

	/* @var string Holds the label (displayed) value of the header */
	public $label;

	/* @var int 0 - form field, 1 - static submission header */
	public $static;

	/* @var int Checks if this header is shown in the submissions list */
	public $enabled;

	public function __construct($value, $label, $static = 0, $formId = 0)
	{
		$this->value = $value;
		$this->label = $label;
		$this->static = $static;

		if ($formId) {
			$this->enabled = $this->isHeaderEnabled($formId);
		}
	}

	public function __toString()
	{
		return $this->value;
	}

	protected function isHeaderEnabled($formId)
	{
		static $cache = array();

		if (!isset($cache[$formId])) {
			$cache[$formId] = (object) array(
				'staticHeaders' => array(),
				'headers'       => array()
			);

			$db = JFactory::getDbo();

			$query = $db->getQuery(true)
				->select($db->qn('ColumnName'))
				->select($db->qn('ColumnStatic'))
				->from($db->qn('#__rsform_submission_columns'))
				->where($db->qn('FormId') . ' = ' . $db->q($formId));

			if ($results = $db->setQuery($query)->loadObjectList()) {
				foreach ($results as $result) {
					if ($result->ColumnStatic) {
						$cache[$formId]->staticHeaders[] = $result->ColumnName;
					} else {
						$cache[$formId]->headers[] = $result->ColumnName;
					}
				}
			}
		}

		$array = $this->static ? 'staticHeaders' : 'headers';

		if (empty($cache[$formId]->headers) && empty($cache[$formId]->staticHeaders)) {
			return true;
		}

		return in_array($this->value, $cache[$formId]->{$array});
	}

	
}
