ALTER TABLE`#__rseventscheckin` ADD COLUMN `ordering` int(11) NOT NULL DEFAULT '0' AFTER `language`;
UPDATE `#__rseventscheckin` SET `ordering` = `id`;