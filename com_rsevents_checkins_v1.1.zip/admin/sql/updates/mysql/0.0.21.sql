ALTER TABLE `#__rseventscheckin` ADD COLUMN `language` CHAR(7) NOT NULL DEFAULT '*' AFTER `alias`;

DROP INDEX `aliasindex` on `#__rseventscheckin`;
CREATE UNIQUE INDEX `aliasindex` ON `#__rseventscheckin` (`alias`, `catid`);