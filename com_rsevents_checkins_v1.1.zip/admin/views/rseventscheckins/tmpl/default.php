<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Factory;

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wa->useScript('jquery');
$lang = JFactory::getLanguage()->getTag();
if (JLanguageMultilang::isEnabled() && $lang)
{
    $query_lang = "&lang={$lang}";
}
else
{
    $query_lang = "";
}
 
 $listOrder	= $this->escape($this->state->get('list.ordering', ''));
 $listDirn	= $this->escape($this->state->get('list.direction', 'desc'));
  $select="$listOrder $listDirn";



?>
<style>
.note-opener{ cursor: pointer; } 
.modal-dialog .modal-body{ padding:1rem}
	.visually-hidden{ display: none;}
	.table td.box{ position: relative;padding-top: 1.2rem; }
	.ribbon {
	--f: 10px;
	--r: 15px;
	--t: 10px;
	color:#fff;
	position: absolute;
	inset: var(--t) calc(-1*var(--f)) auto auto;
	padding: 0 10px var(--f) calc(10px + var(--r));
	clip-path: polygon(0 0,100% 0,100% calc(100% - var(--f)),calc(100% - var(--f)) 100%, calc(100% - var(--f)) calc(100% - var(--f)),0 calc(100% - var(--f)), var(--r) calc(50% - var(--f)/2));
	background: #BD1550;
	box-shadow: 0 calc(-1*var(--f)) 0 inset #0005;
	white-space: nowrap;
	font-size: 12px;
	top: 2px;
	color: #fff;
}
</style>
<form action="<?php echo JRoute::_('index.php?option=com_rseventscheckin'); ?>" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">

	<div class="form-horizontal">
		<fieldset class="adminform">

			<legend><?php echo JText::_('COM_RSEVENTSCHECKIN_LEGEND_DETAILS') ?></legend>
            
			<div class="d-flex flex-row">
				<div>
                    <div class="js-stools-container-bar">
                        <select name="filter_event" class='form-select ' id='event_selector'>

                            <?php
                            foreach ($this->events as $event) {
                            ?>
                                <option <?php if ($this->event_id == $event->value) { ?> selected <?php } ?> value="<?php echo $event->value; ?>"><?php echo JText::_($event->text); ?></option>
                            <?php
                            }
                            ?>

                        </select>
                    </div>
                   
				</div>
            
                <div>
                    <?php  if(!empty($this->filterForm)) { 
                    
                        echo JLayoutHelper::render(
                            'joomla.searchtools.default',
                            array('view' => $this)
                        ); 
                    
                    }  ?>

                </div>
				
			</div>
            
		</fieldset>
	</div>
	<br />

	<?php 
	include_once(__DIR__).'/confirm-list.php'; ?>
    <?php 
	include_once(__DIR__).'/unconfirm-list.php'; ?>

	
	<input type="hidden" name="task" />
	<?php echo JHtml::_('form.token'); ?>
</form>
<div class="modal" tabindex="-1" id="NoteModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_HEADING_LABEL'); ?></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form>

					<div class="mb-3">
						<label for="message-text" class="col-form-label"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_LABEL'); ?></label>
						<textarea class="form-control" rows="8" name='message' id="message"></textarea>
						<input type='hidden' name='field_id' id="field_id">
						<input type='hidden' name='field_id' id="field_id">
						<input type='hidden' name='form_id' id="form_id">
						<input type='hidden' name='submission_id' id="submission_id">
					</div>
				</form>
			</div>
			<div class="modal-footer">

				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_CLOSE_LABEL'); ?></button>
				<?php if ($this->can_edit_subscriptions == 1) { ?>
					<button type="button" class="btn btn-primary" onclick="saveNote()"><?php echo JText::_('COM_RSEVENTSCHECKIN_RSEVENTSCHECKIN_NOTE_SAVE_LABEL'); ?></button>
				<?php } ?>

			</div>
		</div>
	</div>
</div>
 

<script>
	jQuery(document).ready(function($) {
 
	var NoteModal = document.getElementById('NoteModal')
	

	NoteModal.addEventListener('show.bs.modal', function(event) {
		// Button that triggered the modal
		var button = event.relatedTarget
		// Extract info from data-bs-* attributes
		var recipient = button.getAttribute('data-bs-whatever')
		var data_note = button.getAttribute('data-note')
		note_value = '';
		var note_field_id = button.getAttribute('data-noteid');
		if (data_note == 1) {
			note_value = button.parentNode.querySelector('.note-container').innerHTML;

		}
		var note_form_id = button.getAttribute('data-formid');
		var note_submission_id = button.getAttribute('data-submissionid'); 
		// If necessary, you could initiate an AJAX request here
		// and then do the updating in a callback.
		//
		// Update the modal's content.
		var modalTitle = NoteModal.querySelector('.modal-title')
		var modalBodyInput = NoteModal.querySelector('.modal-body #message')
		var modalBodyInput2 = NoteModal.querySelector('.modal-body #field_id')
		var modalBodyInput3 = NoteModal.querySelector('.modal-body #form_id')
		var modalBodyInput4 = NoteModal.querySelector('.modal-body #submission_id')
		//modalTitle.textContent = 'New message to ' + recipient
		modalBodyInput.value = note_value
		modalBodyInput2.value = note_field_id
		modalBodyInput3.value = note_form_id
		modalBodyInput4.value = note_submission_id
	})
	
	saveNote = function() {

			ajaxurl = window.location.href;
			message = jQuery('#NoteModal').find('.modal-body #message').val()

			field_id = jQuery('#NoteModal').find('.modal-body #field_id').val()
			form_id = jQuery('#NoteModal').find('.modal-body #form_id').val()
			submission_id = jQuery('#NoteModal').find('.modal-body #submission_id').val()
			var data = {
				'action': 'ajax_save_note',
				'message': message,
				'field_id': field_id,
				'form_id': form_id,
				'submission_id': submission_id

			};
 
		jQuery('.preloader').removeClass('d-none')	
		jQuery.post(ajaxurl, data)
			.done(function(response) {
				modal_status_changed=true;
				var modal = bootstrap.Modal.getInstance(NoteModal);
				modal.hide();
				jQuery('.note-container-'+submission_id).html(message)
				jQuery('.note_'+submission_id).html(message)
				jQuery('.preloader').addClass('d-none')

		});

	}


		toggleConfirmation = function(confirm_id,code,confirm_status) {
			 
			ajaxurl = window.location.href;
			var data = {
				'action': 'ajax_confirm',
				'confirm': confirm_status,
				'code': code,
				'confirm_id': confirm_id
			};


			jQuery.post(ajaxurl, data)
				.done(function(response) {
					//alert(response)

				});

			/* if (elem.prop('checked') && jQuery('#event_state').prop('checked')) {

				//elem.closest('tr').remove()
			}
			if (!elem.prop('checked') && !jQuery('#event_state').prop('checked')) {

				elem.closest('tr').remove()
			} */

		}
		jQuery('#event_selector').on('change', function() {
			// event_id=jQuery( '#event_selector' ).val();
			jQuery(this).closest('form').submit()
		})

		jQuery('#event_selector').on('change', function() {
			// event_id=jQuery( '#event_selector' ).val();
			jQuery(this).closest('form').submit()
		})
		jQuery('#event_state').on('change', function() {
			// event_id=jQuery( '#event_selector' ).val();

			jQuery(this).closest('form').submit()
		})

	});
</script>