<?php
/**
* @package RSEvents!Pro
* @copyright (C) 2020 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/
defined( '_JEXEC' ) or die( 'Restricted access' );

class RseventsCheckInModelSubscriptions extends JModelList
{
	/**
	 * Constructor.
	 *
	 * @param	array	An optional associative array of configuration settings.
	 * @see		JController
	 * @since	1.6
	 */
	public function __construct($config = array()) {
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'u.name', 'e.name', 'u.id', 'u.date',
				'u.gateway', 'u.state', 'u.confirmed', 
				'state', 'event', 'ticket', 'from', 'to','ticket','Subscription_Note' 
			);
		}
		
		parent::__construct($config);
	}
	
	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function populateState($ordering = 'u.date', $direction = 'desc') {
		// List state information.
		parent::populateState($ordering, $direction);
	}
	
	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return	JDatabaseQuery
	 * @since	1.6
	 */
	protected function getListQuery() {
		$db 	= JFactory::getDBO();
		$query 	= $db->getQuery(true);
		$tz		= rseventsproHelper::getTimezone();
		$cart	= false;
		
		 
		
		$search 	= $this->getState('filter.search');
		$ticket 	= $this->getState('filter.ticket');
		$state		= $this->getState('filter.state');
		$event		= $this->getState('filter.event');
		$from		= $this->getState('filter.from');
		$to			= $this->getState('filter.to');
		$orderby	= $this->getState('list.ordering', 'u.date');
		$orderdir	= $this->getState('list.direction', 'desc');
	 
		$from	= $from ? JFactory::getDate($from, $tz)->toSql() : '';
		if ($to) {
			$to = JFactory::getDate($to,$tz);
			$to->setTime(23,59,59);
			$to = $to->toSql();
		}
		
		require_once JPATH_SITE. '/components/com_rseventscheckin/helpers/subscriptions.php';
		
		$subscriptionsClass = new RSEventsCheckINSubscriptions;
		
		if (!empty($search)) {
			$subscriptionsClass->setFilter('search', $search);
		}
		
		if (is_numeric($ticket)) {
			$subscriptionsClass->setFilter('ticket', $ticket);
		}
		
		if (is_numeric($event)) {
			$subscriptionsClass->setFilter('ide', $event);
		}
		
		if ($state != '') {
			$subscriptionsClass->setFilter('state', $state);
		}
		 
		$subscriptionsClass->setFilter('cart', $cart);
		$subscriptionsClass->setFilter('from', $from);
		$subscriptionsClass->setFilter('to', $to);
		$subscriptionsClass->setFilter('list.order', $orderby);
		$subscriptionsClass->setFilter('list.dir', $orderdir);
		
		return $subscriptionsClass::getSubscriptionsQuery();
	}
}