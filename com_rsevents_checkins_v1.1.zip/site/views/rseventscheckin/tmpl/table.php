<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rseventscheckin
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
$lang = JFactory::getLanguage()->getTag();
if (JLanguageMultilang::isEnabled() && $lang)
{
    $query_lang = "&lang={$lang}";
}
else
{
    $query_lang = "";
}
 
$listOrder	= $this->escape($this->state->get('list.ordering', ''));
$listDirn	= $this->escape($this->state->get('list.direction', 'desc'));
$select="$listOrder $listDirn";
include_once(__DIR__).'/list.php';
?>
	 