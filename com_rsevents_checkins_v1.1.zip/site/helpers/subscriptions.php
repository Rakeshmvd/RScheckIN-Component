<?php
/**
* @package RSEvents!Pro
* @copyright (C) 2020 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/
defined( '_JEXEC' ) or die( 'Restricted access' );

class RSEventsCheckInSubscriptions
{	
	/**
	 * Filters for subscriptions
	 *
	 * @var    array
	 */
	protected static $filters = array();
	
	protected static $table;
	
	public function setFilter($type, $value) {
		self::$filters[$type] = $value;
	}
	
	public static function getSubscriptionsQuery() {
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$from	= array_key_exists('from', self::$filters) ? self::$filters['from'] : '';
		$to		= array_key_exists('to', self::$filters) ? self::$filters['to'] : '';
		
		$barcode_prefix = rseventsproHelper::getBarcodeOptions('barcode_prefix', 'RST-');
		
		$query->clear()
			->select('u.*')
			->select($db->qn('e.name','event'))->select($db->qn('e.start')   )
			->select($db->qn('e.end'))->select($db->qn('e.allday'))
			->select($db->qn('e.form')) 
			->from($db->qn('#__rseventspro_users','u'))
			->join('left',$db->qn('#__rseventspro_events','e').' ON '.$db->qn('e.id').' = '.$db->qn('u.ide'));
		
		if (array_key_exists('tickets', self::$filters) || array_key_exists('ticket', self::$filters)) {
			$query->join('left',$db->qn('#__rseventspro_user_tickets','ut').' ON '.$db->qn('ut.ids').' = '.$db->qn('u.id'));
			
		}
		$orderby 	= array_key_exists('list.order', self::$filters) ? self::$filters['list.order'] : 'u.date';
		if ($orderby=='Subscription_Note' || $orderby=='ticket'   ) {
			self::$filters['list.order']='FieldValue';
			$query->select($db->qn('ut.FieldValue','Subscription_Note')) ;
			$query->join('left',$db->qn('#__rsform_submission_values','ut').' ON '.$db->qn('ut.SubmissionId').' = '.$db->qn('u.SubmissionId')
			.' And ' . $db->qn('ut.FieldName') . ' = ' . $db->q('Subscription_Note')
					);
			$query->group(array($db->qn('u.id')));
		}

		 
		
		 if ($orderby=='ticket'   ) {
			self::$filters['list.order']='ticket_name';
			$query->select($db->qn('t.name','ticket_name'));
			$query->join('left',$db->qn('#__rseventspro_user_tickets','uts').' ON '.$db->qn('u.id').' = '.$db->qn('uts.ids'));
		
			$query->join('left',$db->qn('#__rseventspro_tickets','t').' ON '.$db->qn('t.id').' = '.$db->qn('uts.idt'));
			 
		}
		
		if (array_key_exists('ide', self::$filters)) {
			$query->where($db->qn('u.ide').' = '. (int) self::$filters['ide']);
		}
		
		if (array_key_exists('search', self::$filters)) {
			$where	= array();
			$search = $db->q('%'.$db->escape(self::$filters['search'], true).'%');
			
			if (array_key_exists('tickets', self::$filters) && strpos(self::$filters['search'], $barcode_prefix) !== false) {
				$limit = 10;
				
				if (array_key_exists('ide', self::$filters)) {
					$subquery = $db->getQuery(true);
					
					$subquery->clear()
						->select('MAX('.$db->qn('ut.quantity').')')
						->from($db->qn('#__rseventspro_users','u'))
						->join('left',$db->qn('#__rseventspro_user_tickets','ut').' ON '.$db->qn('ut.ids').' = '.$db->qn('u.id'))
						->where($db->qn('u.ide').' = '. (int) self::$filters['ide'])
						->where($db->qn('ut.idt').' <> 0');
					
					JFactory::getApplication()->triggerEvent('onrsepro_subscriptionsQuery', array(array('query' => &$subquery, 'rule' => 'u.ide')));
					
					$db->setQuery($subquery);
					$limit = (int) $db->loadResult();
				}
				
				if ($limit) {
					$search = str_replace($barcode_prefix, '', $search);
					
					for ($i=1;$i<=$limit;$i++) {
						$where[] = 'CONCAT_WS("-",'.$db->qn('u.id').',CONCAT(SUBSTR(MD5(CONCAT('.$db->qn('u.id').', '.$db->qn('t.id').', '.$i.')), 1, 4), SUBSTR(MD5(CONCAT('.$db->qn('u.id').', '.$db->qn('t.id').', '.$i.')), -4))) LIKE '.$search;
					}
				}
			}
			
			$where = !empty($where) ? ' OR '.implode(' OR ', $where) : '';
			$query->where('('.$db->qn('e.name').' LIKE '.$search.' OR '.$db->qn('u.name').' LIKE '.$search.' OR '.$db->qn('u.email').' LIKE '.$search.$where.')');
		}
		
		if (array_key_exists('ticket', self::$filters)) {
			$query->where($db->qn('ut.idt').' = '.(int) self::$filters['ticket']);
		}
		
		if (array_key_exists('state', self::$filters)) {
			$query->where($db->qn('u.state').' = '.(int) self::$filters['state']);
		}
		
		if (array_key_exists('language', self::$filters)) {
			$query->where($db->qn('u.lang').' = '.$db->q(self::$filters['language']));
		}
		
		if (array_key_exists('payment', self::$filters)) {
			if (self::$filters['payment'] == 'none') self::$filters['payment'] = '';
			$query->where($db->qn('u.gateway').' = '.$db->q(self::$filters['payment']));
		}
		
		if (array_key_exists('cart', self::$filters) && !self::$filters['cart']) {
			$query->where($db->qn('e.id').' <> 0');
		}
		
		if (empty($from) && !empty($to)) {
			$query->where($db->qn('u.date').' <= '.$db->q($to));
		} elseif (!empty($from) && empty($to)) {
			$query->where($db->qn('u.date').' >= '.$db->q($from));
		} elseif (!empty($from) && !empty($to)) {
			$query->where($db->qn('u.date').' >= '.$db->q($from));
			$query->where($db->qn('u.date').' <= '.$db->q($to));
		}
		
		$orderby 	= array_key_exists('list.order', self::$filters) ? self::$filters['list.order'] : 'u.date';
		$orderdir	= array_key_exists('list.dir', self::$filters) ? self::$filters['list.dir'] : 'DESC';
		 
		$query->order($db->qn($orderby).' '.$orderdir);
		JFactory::getApplication()->triggerEvent('onrsepro_subscriptionsQuery', array(array('query' => &$query, 'rule' => 'u.ide')));
		 
		return $query;
	}
	
	public static function getSubscription($id) {
		self::$table = JTable::getInstance('Subscription','rseventsproTable');
		
		self::$table->load($id);
		
		if (self::$table->gateway == 'offline') {
			self::$table->tparams = rseventsproHelper::getCardDetails(self::$table->id);
		} else {
			self::$table->tparams = self::$table->params;
		}
		
		self::$table->subscriptionTickets		= null;
		self::$table->subscriptionEvent			= null;
		self::$table->subscriptionRsformFields	= null;
		self::$table->subscriptionForm			= null;
		
		return new static();
	}
	
	public static function attachTickets() {
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		
		$query->clear()
			->select($db->qn('ut.quantity'))->select($db->qn('t').'.*')
			->from($db->qn('#__rseventspro_user_tickets','ut'))
			->join('left',$db->qn('#__rseventspro_tickets','t').' ON '.$db->qn('t.id').' = '.$db->qn('ut.idt'))
			->where($db->qn('ut.ids').' = '.$db->q(self::$table->id));
		
		$db->setQuery($query);
		self::$table->subscriptionTickets = $db->loadObjectList();
		
		return new static();
	}
	
	public static function attachEvent($id = null) {
		$db		= JFactory::getDbo();
		$query	= $db->getQuery(true);
		$id		= is_null($id) ? self::$table->ide : $id;
		
		$query->clear()
			->select($db->qn('id'))->select($db->qn('name'))
			->select($db->qn('owner'))->select($db->qn('ticketsconfig'))
			->from($db->qn('#__rseventspro_events'))
			->where($db->qn('id').' = '.$db->q($id));
		
		$db->setQuery($query);
		self::$table->subscriptionEvent = $db->loadObject();
		
		return new static();
	}
	
	public static function attachRsformFields() {
		self::$table->subscriptionRsformFields = rseventsproHelper::getRSFormData(self::$table->id);
		
		return new static();
	}
	
	public static function attachForm() {
		$form = JForm::getInstance('subscriber', JPATH_SITE.'/components/com_rseventspro/models/forms/subscriber.xml', array('control' => 'jform'));
		$form->bind(self::$table);
		
		self::$table->subscriptionForm = $form;
		
		return new static();
	}
	
	public static function getData() {
		return self::$table;
	}
}